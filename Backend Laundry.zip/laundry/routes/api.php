<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\Admin\RoleController;
use App\Http\Controllers\Api\Admin\PermissionController;
use App\Http\Controllers\Api\Admin\UserController;
use App\Http\Controllers\Api\Admin\LaundryStoreController;
use App\Http\Controllers\Api\Customer\CheckoutController; // Import CheckoutController
use App\Http\Controllers\Api\Customer\PesananController;
use App\Http\Controllers\Api\Admin\AdminPesananController;
use App\Http\Controllers\Api\CategoryController;
use App\Http\Controllers\Api\Auth\LoginController;
use App\Http\Controllers\Api\Customer\ProfileController;
use App\Http\Controllers\Api\Admin\KecController;
use App\Http\Controllers\Api\Admin\KelController;
use App\Http\Controllers\Api\Admin\AdminOrderController;
use App\Http\Controllers\Api\Customer\NotificationController;
use App\Http\Controllers\Api\Customer\PaymentController;
use App\Http\Controllers\Api\Customer\RatingController;
use App\Http\Controllers\Api\Customer\AccountController; 
use App\Http\Controllers\Api\ChatController;
use App\Http\Controllers\Api\Admin\BannerController;
use App\Http\Controllers\Api\Admin\AdminDashboardController;
use App\Http\Controllers\Api\Admin\Voucher1Controller;
use App\Http\Controllers\Api\Customer\ClaimVoucher1Controller;
use App\Http\Controllers\Api\Admin\Voucher2Controller;
use App\Http\Controllers\Api\Customer\ClaimVoucher2Controller;
use App\Http\Controllers\Api\Customer\LoyaltyController;
use App\Http\Controllers\Api\Customer\Loyalty2Controller;
use App\Http\Controllers\Api\Customer\ShowingVoucherController;
use App\Http\Controllers\Api\Admin\AuditLogController;
use App\Http\Controllers\Api\Admin\AdminNotificationController;
use App\Http\Controllers\Api\Admin\KaryawanController;
use App\Http\Controllers\Api\Admin\BonusController;
use App\Http\Controllers\Api\Admin\PeralatanController;
use App\Http\Controllers\Api\Auth\PasswordResetController;
use App\Http\Controllers\Api\Admin\DataAkunController;
use App\Http\Controllers\Api\Admin\BanController;



/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

/**
 * route "/register"
 * @method "POST"
 */
Route::post('/register', App\Http\Controllers\Api\Auth\RegisterController::class)->name('register');

// Login lokal menggunakan email atau username
Route::post('/login-local', [LoginController::class, 'loginLocal'])->name('auth.login.local');
    
Route::post('/login-google', [LoginController::class, 'loginGoogle'])->name('auth.login.google');

Route::post('/forgot-password', [PasswordResetController::class, 'sendResetLink'])->middleware('api');
Route::post('/reset-password', [PasswordResetController::class, 'resetPassword'])->middleware('api');



// group route with middleware "auth"
Route::group(['middleware' => 'auth:api'], function() {
    
    // logout
    Route::post('/logout', [App\Http\Controllers\Api\Auth\LoginController::class, 'logout']);
});

Route::prefix('admin')->group(function () {
    Route::middleware(['auth:api', 'checkRole:1'])->group(function () {
        
      Route::get('/provinsi', [KelController::class, 'getProvinces']); // Get all provinces

Route::get('/kabkota/{provinceId}', [KelController::class, 'getCities']); // Get cities by province ID

Route::get('/kecamatan/{cityId}', [KelController::class, 'getDistricts']); // Get districts by city ID

Route::get('/kelurahan/{districtId}', [KelController::class, 'getDistricts']); // Get sub-districts by district ID

Route::get('/kodepos/{cityId}/{districtId}', [KelController::class, 'getPostalCodes']); // Get postal codes

Route::get('/cari/{keyword}', [KelController::class, 'searchLocation']); // Search location
        
        Route::post('/ban', [BanController::class, 'banUser']); // Ban a user
Route::delete('/unban/{id}', [BanController::class, 'unbanUser']); // Unban a user
Route::get('/banned-users', [BanController::class, 'bannedUsers']);
        
        Route::get('akun', [DataAkunController::class, 'index']);
        Route::get('akun/{id}', [DataAkunController::class, 'show']);
        Route::get('akun/{id}/profile', [DataAkunController::class, 'profile']);
        
        // Route for getting ratings (index)
        Route::get('ratings', [RatingController::class, 'index']);
        
        Route::get('peralatan', [PeralatanController::class, 'index']);
        Route::post('peralatan', [PeralatanController::class, 'store']);
        Route::get('peralatan/{id}', [PeralatanController::class, 'show']);
        Route::put('peralatan/{id}', [PeralatanController::class, 'update']);
        Route::delete('peralatan/{id}', [PeralatanController::class, 'destroy']);
        
        Route::get('bonus', [BonusController::class, 'index']);
        Route::post('bonus', [BonusController::class, 'store']);
        Route::get('bonus/{id}', [BonusController::class, 'show']);
        Route::put('bonus/{id}', [BonusController::class, 'update']);
        Route::delete('bonus/{id}', [BonusController::class, 'destroy']);
        
        Route::get('karyawan', [KaryawanController::class, 'index']); // Menampilkan daftar karyawan
        Route::post('karyawan', [KaryawanController::class, 'store']); // Menambahkan karyawan baru
        Route::get('karyawan/{karyawan}', [KaryawanController::class, 'show']); // Menampilkan karyawan berdasarkan ID
        Route::put('karyawan/{karyawan}', [KaryawanController::class, 'update']); // Mengupdate data karyawan
        Route::delete('karyawan/{karyawan}', [KaryawanController::class, 'destroy']); // Menghapus karyawan
        
        // Menampilkan semua notifikasi yang dikirim oleh customer
        Route::get('notifications', [AdminNotificationController::class, 'index']);

        // Menghapus notifikasi berdasarkan ID
        Route::delete('notifications/{notificationId}', [AdminNotificationController::class, 'delete']);
        
        Route::get('audit-logs', [AuditLogController::class, 'index']);
        
        // Route untuk menampilkan semua data loyalty
        Route::get('/loyalties', [LoyaltyController::class, 'index']);
        // Route untuk menampilkan detail data loyalty berdasarkan ID
        Route::get('/loyalties/{id}', [LoyaltyController::class, 'show']);
        
        Route::get('vouchers1', [Voucher1Controller::class, 'index']);
        Route::post('vouchers1', [Voucher1Controller::class, 'store']);
        Route::get('vouchers1/{voucher}', [Voucher1Controller::class, 'show']);
        Route::put('vouchers1/{voucher}', [Voucher1Controller::class, 'update']);
        Route::delete('vouchers1/{voucher}', [Voucher1Controller::class, 'destroy']);
        
        Route::get('vouchers2', [Voucher2Controller::class, 'index']);
        Route::post('vouchers2', [Voucher2Controller::class, 'store']);
        Route::get('vouchers2/{voucher}', [Voucher2Controller::class, 'show']);
        Route::put('vouchers2/{voucher}', [Voucher2Controller::class, 'update']);
        Route::delete('vouchers2/{voucher}', [Voucher2Controller::class, 'destroy']);
        
        Route::get('dashboard', [AdminDashboardController::class, 'index']);
        
        Route::get('/pesanannn/{id}', [AdminPesananController::class, 'show']);
        Route::get('/pesanannn', [AdminPesananController::class, 'index']);
        
        Route::get('banner', [BannerController::class, 'index']);
        Route::get('banner/{id}', [BannerController::class, 'show']);
        Route::post('banner', [BannerController::class, 'store']);
        Route::delete('banner/{id}', [BannerController::class, 'destroy']);
        
        Route::get('/chat/messages', [ChatController::class, 'fetchMessages']); // Ambil semua pesan
        Route::post('/chat/send', [ChatController::class, 'sendMessage']); // Kirim pesan
        Route::get('/chat/users', [ChatController::class, 'fetchUsers']); // Ambil semua pengguna (khusus admin)
        
        Route::put('orders/{orderId}/status', [AdminOrderController::class, 'updateStatus']);
        
        // permissions
        Route::get('/permissions', [\App\Http\Controllers\Api\Admin\PermissionController::class, 'index'])->middleware('permission:permissions.index');
        
        // permissions all
        Route::get('/permissions/all', [\App\Http\Controllers\Api\Admin\PermissionController::class, 'all'])->middleware('permission:permissions.index');
        
        // roles all
        Route::get('/roles/all', [\App\Http\Controllers\Api\Admin\RoleController::class, 'all'])->middleware('permission:roles.index');
        
        // roles
        Route::apiResource('/roles', App\Http\Controllers\Api\Admin\RoleController::class)
            ->middleware('permission:roles.index|roles.store|roles.update|roles.delete');
        
        // users
        Route::apiResource('/users', App\Http\Controllers\Api\Admin\UserController::class)
            ->middleware('permission:users.index|users.store|users.update|users.delete');
        
        Route::get('laundry-stores', [LaundryStoreController::class, 'index']);
        Route::post('laundry-stores', [LaundryStoreController::class, 'store']);
        Route::get('laundry-stores/all', [LaundryStoreController::class, 'all']);
        Route::get('laundry-stores/{id}', [LaundryStoreController::class, 'show']);
        Route::patch('laundry-stores/{laundryStore}', [LaundryStoreController::class, 'update']);
        Route::delete('laundry-stores/{laundryStore}', [LaundryStoreController::class, 'destroy']);

        Route::get('/pesanan/all', [PesananController::class, 'all']);

        Route::get('/categories', [CategoryController::class, 'index'])->name('categories.index');
Route::post('/categories/{category}/update-price', [CategoryController::class, 'updatePrice'])->name('categories.updatePrice');

        Route::get('kec', [KecController::class, 'index']); // Menampilkan daftar kecamatan
        Route::post('kec', [KecController::class, 'store']); // Menambahkan kecamatan baru
        Route::get('kec/{id}', [KecController::class, 'show']); // Menampilkan detail kecamatan berdasarkan ID
        Route::put('kec/{kec}', [KecController::class, 'update']); // Mengupdate kecamatan berdasarkan ID
        Route::delete('kec/{kec}', [KecController::class, 'destroy']); // Menghapus kecamatan berdasarkan ID

        Route::get('kel', [KelController::class, 'index']); // Menampilkan daftar kelurahan
        Route::post('kel', [KelController::class, 'store']); // Menambahkan kelurahan baru
        Route::get('kel/{id}', [KelController::class, 'show']); // Menampilkan detail kelurahan berdasarkan ID
        Route::put('kel/{kel}', [KelController::class, 'update']); // Mengupdate kelurahan berdasarkan ID
        Route::delete('kel/{kel}', [KelController::class, 'destroy']); // Menghapus kelurahan berdasarkan ID
        
    });
});

Route::prefix('customer')->group(function () {
    Route::middleware(['auth:api', 'checkRole:2'])->group(function () {

        Route::get('/show-active1', [ShowingVoucherController::class, 'showAllClaimVoucher1']);
        Route::get('/show-active2', [ShowingVoucherController::class, 'showAllClaimVoucher2']);
        
        Route::get('/loyalty2', [Loyalty2Controller::class, 'index']); // Menampilkan semua data yang valid untuk user login
        Route::get('/loyalty2/{id}', [Loyalty2Controller::class, 'show']); // Menampilkan detail data berdasarkan ID untuk user login
        
        // Route untuk menampilkan semua data loyalty
        Route::get('/loyalties', [LoyaltyController::class, 'index']);
        // Route untuk menampilkan detail data loyalty berdasarkan ID
        Route::get('/loyalties/{id}', [LoyaltyController::class, 'show']);

        Route::get('vouchers1', [ClaimVoucher1Controller::class, 'index']);
        Route::post('claim-voucher1', [ClaimVoucher1Controller::class, 'store']);

        Route::get('/show-vouchers1', [ClaimVoucher1Controller::class, 'activeVouchers']);
        Route::get('/show-vouchers2', [ClaimVoucher2Controller::class, 'activeVouchers']);
        Route::get('vouchers2', [ClaimVoucher2Controller::class, 'index']);

        Route::post('claim-voucher2', [ClaimVoucher2Controller::class, 'store']);
        
        Route::get('banner', [BannerController::class, 'index']);
        Route::get('banner/{id}', [BannerController::class, 'show']);
        
        Route::get('/messages', [ChatController::class, 'fetchMessages']);
        Route::post('/messages', [ChatController::class, 'sendMessage']);
        
        Route::put('account', [AccountController::class, 'update']);
        
        // Route to update an existing rating
        Route::put('ratings/{id}', [RatingController::class, 'update']);
        
        // Route for storing a rating
        Route::post('ratings', [RatingController::class, 'store']);
    
        // Route for getting ratings (index)
        Route::get('ratings', [RatingController::class, 'index']);
        
        
        Route::post('/midtrans/callback', [PaymentController::class, 'callback']);

        Route::post('/payment/generate-snap-token/{orderId}', [PaymentController::class, 'generateSnapToken']);
        
        // Route to get all notifications for the authenticated user
         Route::get('/notifications', [NotificationController::class, 'index']);

        // Route to delete a notification
        Route::delete('/notifications/{notificationId}', [NotificationController::class, 'delete']);
        
        // Route for updating the status of an order
        Route::put('orders/{id}/status', [PesananController::class, 'updateStatus']);
        
        Route::post('/logout', [LoginController::class, 'logout']);

        // Laundry store routes
        Route::get('laundry-stores', [LaundryStoreController::class, 'index']);
        Route::post('laundry-stores', [LaundryStoreController::class, 'store']);
        Route::get('laundry-stores/all', [LaundryStoreController::class, 'all']);
        Route::get('laundry-stores/{id}', [LaundryStoreController::class, 'show']);

        // Checkout route
        Route::post('/checkout', [CheckoutController::class, 'checkout'])->name('checkout');
        Route::get('/pesanan', [PesananController::class, 'index']);
        Route::get('/user', [UserController::class, 'getLoggedInUser']);
        Route::get('/categories/{id}', [CategoryController::class, 'show']);
        Route::get('/pesanan/{id}', [PesananController::class, 'show']);

        Route::get('/profiles', [ProfileController::class, 'index']);          // List semua profil
        Route::post('/profiles', [ProfileController::class, 'store']);        // Simpan profil baru
        Route::get('/profiles/{id}', [ProfileController::class, 'show']);     // Lihat detail profil
        Route::post('/profiles/{id}', [ProfileController::class, 'update']);  // Update profil, termasuk avatar
        Route::delete('/profiles/{id}', [ProfileController::class, 'destroy']); // Hapus profil

        Route::delete('profiles/{id}/remove-avatar', [ProfileController::class, 'removeAvatar']);

        Route::get('kec', [KecController::class, 'index']); // Menampilkan daftar kecamatan
        Route::get('kel', [KelController::class, 'index']); // Menampilkan daftar kelurahan
        Route::get('kec/{id}', [KecController::class, 'show']);
        Route::get('kel/{id}', [KelController::class, 'show']);

    });
});
