<?php

use Illuminate\Support\Facades\Broadcast;

/*
|--------------------------------------------------------------------------
| Broadcast Channels
|--------------------------------------------------------------------------
|
| Here you may register all of the event broadcasting channels that your
| application supports. The given channel authorization callbacks are
| used to check if an authenticated user can listen to the channel.
|
*/

Broadcast::channel('chat.{receiverId}', function ($user, $receiverId) {
    // Admin (role_id 1) dapat mendengarkan semua channel
    if ($user->role_id == 1) {
        return true;
    }

    // Pengguna biasa hanya dapat mendengarkan channel mereka sendiri
    return (int) $user->id === (int) $receiverId;
});


