<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
</head>
<body style="font-family: Arial, sans-serif; background-color: #f8f9fa; margin: 0; padding: 0; color: #000000;">
    <table cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px; background-color: #ffffff; border-radius: 8px; overflow: hidden; margin: 20px auto; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);">
        <tr>
            <td style="background-color: #007BFF; color: #ffffff; padding: 20px; text-align: center;">
                <h1 style="margin: 0; font-size: 20px; font-weight: bold;">Reset Password</h1>
            </td>
        </tr>
        <tr>
            <td style="padding: 20px 30px; color: #333333;">
                <p style="font-size: 14px; line-height: 1.8; margin: 0;">
                    Hai <strong>Sobat Laundryku!</strong>,
                </p>
                <p style="font-size: 13px; line-height: 1.8; margin: 15px 0;">
                    Kami menerima permintaan untuk mereset password akun Anda. Berikut adalah kode token untuk melanjutkan proses reset password:
                </p>
                <div style="text-align: center; margin: 20px 0;">
                    <span style="display: inline-block; padding: 10px 30px; font-size: 20px; color: #ffffff; background-color: #007BFF; border-radius: 5px; font-weight: bold; letter-spacing: 1px;">
                        <?php echo e($code); ?>

                    </span>
                </div>
                <p style="font-size: 13px; line-height: 1.8; margin: 15px 0;">
                    Masukkan kode ini di halaman reset password. Jika Anda tidak meminta reset password, abaikan email ini, dan akun Anda tetap aman.
                </p>
            </td>
        </tr>
        <tr>
            <td style="background-color: #f8f9fa; text-align: center; padding: 15px 20px; font-size: 12px; color: #6c757d;">
                <p style="margin: 0; color: #000000;">© <?php echo e(date('Y')); ?> Laundryku. Semua hak dilindungi.</p>
                <p style="margin: 5px 0;">
                    <a href="<?php echo e(url('/')); ?>" style="color: #007BFF; text-decoration: none;">Kebijakan Privasi</a> | 
                    <a href="<?php echo e(url('/')); ?>" style="color: #007BFF; text-decoration: none;">Syarat dan Ketentuan</a>
                </p>
            </td>
        </tr>
    </table>
</body>
</html>
<?php /**PATH /home/pplg7898/public_html/laundryku-db/resources/views/emails/password_reset.blade.php ENDPATH**/ ?>