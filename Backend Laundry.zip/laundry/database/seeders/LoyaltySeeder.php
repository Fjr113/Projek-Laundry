<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Loyalty;

class LoyaltySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $data = [
            ['nama' => 'Fresh'],
            ['nama' => 'Flawless'],
            ['nama' => 'Elegant'],
            ['nama' => 'Luxury'],
            ['nama' => 'Majestic'],
            ['nama' => 'Supreme'],
        ];

        foreach ($data as $item) {
            Loyalty::create($item);
        }
    }
}
