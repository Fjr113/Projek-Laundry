<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class KelSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $data = [
            ['nama' => 'Cemplang', 'kec_id' => 1],
            ['nama' => 'Ciapus', 'kec_id' => 1],
            ['nama' => 'Ciomas', 'kec_id' => 1],
            ['nama' => 'Kota Batu', 'kec_id' => 1],
            ['nama' => 'Laladon', 'kec_id' => 1],
            ['nama' => 'Mekarjaya', 'kec_id' => 1],
            ['nama' => 'Padasuka', 'kec_id' => 1],
            ['nama' => 'Pagelaran', 'kec_id' => 1],
            ['nama' => 'Parakan', 'kec_id' => 1],
            ['nama' => 'Sukaberes', 'kec_id' => 1],
            ['nama' => 'Sukaharja', 'kec_id' => 1],
            ['nama' => 'Sukamakmur', 'kec_id' => 1],
            ['nama' => 'Babakan', 'kec_id' => 2],
            ['nama' => 'Ciherang', 'kec_id' => 2],
            ['nama' => 'Cikarawang', 'kec_id' => 2],
            ['nama' => 'Dramaga', 'kec_id' => 2],
            ['nama' => 'Neglasari', 'kec_id' => 2],
            ['nama' => 'Petir', 'kec_id' => 2],
            ['nama' => 'Purwasari', 'kec_id' => 2],
            ['nama' => 'Sinar Sari', 'kec_id' => 2],
            ['nama' => 'Sukadamai', 'kec_id' => 2],
            ['nama' => 'Sukawening', 'kec_id' => 2],
        ];

        foreach ($data as &$item) {
            // Menghasilkan fee kelipatan 1000 di rentang 7000 - 20000
            $item['fee'] = rand(7, 20) * 1000; 
            $item['created_at'] = now();
            $item['updated_at'] = now();
        }

        DB::table('kel')->insert($data);
    }
}