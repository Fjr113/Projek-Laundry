<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\User;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class UserTableSeeder extends Seeder
{
    public function run(): void
    {
    
    // Menetapkan izin untuk peran 'admin'
    $admin = Role::find(1);
    $adminPermissions = Permission::whereIn('id', [1,2,3,4,5,6,7,8,9,10,11,12,13])->get();
    $admin->syncPermissions($adminPermissions);

    // Menetapkan izin untuk peran 'customer'
    $customer = Role::find(2);
    $customerPermissions = Permission::whereIn('id', [10,14,15,16,17])->get();
    $customer->syncPermissions($customerPermissions);
    
    /**
     * Run the database seeds.
     */
    
        $admin = User::create([
            'username' => 'Mindi',
            'email' => 'admin@gmail.com',
            'password' => bcrypt('4DM1n74UnD2ykUZq014b'),
            'role_id' => 1,
        ]);
        $admin->assignRole('admin');

        $customer = User::create([
            'username' => 'betatestcust002',
            'email' => 'customer@gmail.com',
            'password' => bcrypt('CU573e74kdl'),
            'role_id' => 2,
        ]);
        $customer->assignRole('customer');

    }
}
