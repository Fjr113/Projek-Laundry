<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class KecSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('kec')->insert([
            'nama' => 'Ciomas',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        DB::table('kec')->insert([
            'nama' => 'Dramaga',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }
}