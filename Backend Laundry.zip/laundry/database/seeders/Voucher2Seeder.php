<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class Voucher2Seeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $vouchers = [
            [
                'nama' => 'Gratis Ongkir Khusus Pelanggan Fresh',
                'harga' => '20000',
                'qty' => '1000',
            ],
            [
                'nama' => 'Gratis Ongkir Khusus Pelanggan Flawless',
                'harga' => '20000',
                'qty' => '1000',
            ],
            [
                'nama' => 'Gratis Ongkir Khusus Pelanggan Elegant',
                'harga' => '20000',
                'qty' => '1000',
            ],
            [
                'nama' => 'Gratis Ongkir Khusus Pelanggan Luxury',
                'harga' => '20000',
                'qty' => '1000',
            ],
            [
                'nama' => 'Gratis Ongkir Khusus Pelanggan Majestic',
                'harga' => '20000',
                'qty' => '1000',
            ],
            [
                'nama' => 'Gratis Ongkir Khusus Pelanggan Supreme',
                'harga' => '20000',
                'qty' => '1000',
            ],
        ];

        foreach ($vouchers as $voucher) {
            DB::table('voucher2')->insert([
                'nama' => $voucher['nama'],
                'harga' => $voucher['harga'],
                'qty' => $voucher['qty'],
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}