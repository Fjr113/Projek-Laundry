<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class StatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('statuses')->insert([
            ['name' => 'Belum Bayar', 'created_at' => now(), 'updated_at' => now()],
            ['name' => 'Dalam Proses', 'created_at' => now(), 'updated_at' => now()],
            ['name' => 'Dikirim', 'created_at' => now(), 'updated_at' => now()],
            ['name' => 'Selesai', 'created_at' => now(), 'updated_at' => now()],
            ['name' => 'Dibatalkan', 'created_at' => now(), 'updated_at' => now()],
        ]);
    }
}