<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class Voucher1Seeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $vouchers = [
            [
                'nama' => 'Discount 30% Khusus Pelanggan Fresh',
                'harga' => '30',
                'qty' => '1000',
                'min' => '10000',
                'max' => '40000',
            ],
            [
                'nama' => 'Discount 40% Khusus Pelanggan Flawless',
                'harga' => '40',
                'qty' => '1000',
                'min' => '15000',
                'max' => '50000',
            ],
            [
                'nama' => 'Discount 45% Khusus Pelanggan Elegant',
                'harga' => '45',
                'qty' => '1000',
                'min' => '10000',
                'max' => '55000',
            ],
            [
                'nama' => 'Discount 50% Khusus Pelanggan Luxury',
                'harga' => '50',
                'qty' => '1000',
                'min' => '20000',
                'max' => '70000',
            ],
            [
                'nama' => 'Discount 60% Khusus Pelanggan Majestic',
                'harga' => '60',
                'qty' => '1000',
                'min' => '20000',
                'max' => '75000',
            ],
            [
                'nama' => 'Discount 75% Khusus Pelanggan Supreme',
                'harga' => '75',
                'qty' => '1000',
                'min' => '0',
                'max' => '150000',
            ],
        ];

        foreach ($vouchers as $voucher) {
            DB::table('voucher1')->insert([
                'nama' => $voucher['nama'],
                'harga' => $voucher['harga'],
                'qty' => $voucher['qty'],
                'min' => $voucher['min'],
                'max' => $voucher['max'],
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}