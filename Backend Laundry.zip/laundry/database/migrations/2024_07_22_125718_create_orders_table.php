<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->unsignedBigInteger('category_id')->references('id')->on('categories')->onDelete('cascade');
            $table->unsignedBigInteger('kel_id')->nullable()->references('id')->on('kel')->onDelete('cascade'); // Make kel_id nullable
            $table->decimal('total_price', 8, 2);
            $table->integer('qty');
            $table->string('name');
            $table->text('address')->nullable(); // Address is already nullable
            $table->unsignedBigInteger('delivery_method_id')->references('id')->on('delivery_methods')->onDelete('cascade');
            $table->unsignedBigInteger('payment_method_id')->references('id')->on('payment_methods')->onDelete('cascade');
            $table->unsignedBigInteger('status_id')->references('id')->on('statuses')->onDelete('cascade');
            $table->string('order_code');
            $table->string('tanggal_pesan')->nullable();
            $table->string('tanggal_selesai')->nullable();
            $table->unsignedBigInteger('voucher1_id')->nullable()->references('id')->on('voucher1')->onDelete('cascade');
            $table->unsignedBigInteger('voucher2_id')->nullable()->references('id')->on('voucher2')->onDelete('cascade');


            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders');
    }
}
