<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAuditTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('audit', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id')->nullable(); // ID pengguna yang melakukan aksi
            $table->string('action'); // Aksi yang dilakukan (contoh: login, update, delete)
            $table->string('description'); // Aksi yang dilakukan (contoh: login, update, delete)
            $table->timestamp('created_at')->useCurrent(); // Tanggal dan waktu aksi

            // Tambahkan indeks untuk performa
            $table->index('user_id');
            $table->index('created_at');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('audit');
    }
}
