<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class LaundryStore extends Model
{
    use HasFactory;

    protected $fillable = [
        'address', 'image', 'title', 'phone_num', 'description', 'price', 'rating'
    ];

     /**
     * Get the user that owns the laundry store.
     * 
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Accessor for image attribute.
     * 
     * @param string $image
     * @return string
     */
    public function getImageAttribute($image)
    {
        return Storage::url('images/' . $image);
    }
    
}
