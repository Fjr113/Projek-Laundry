<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Voucher2 extends Model
{
    use HasFactory;

    // Menentukan nama tabel secara eksplisit
    protected $table = 'voucher2';

    // Menentukan kolom yang dapat diisi
    protected $fillable = [
        'nama',
        'harga',
        'qty',
    ];

    /**
     * Fungsi untuk mengurangi kuantitas voucher saat klaim
     */
    public function decreaseQuantity()
    {
        if ($this->qty > 0) {
            $this->decrement('qty');
        }
    }
}
