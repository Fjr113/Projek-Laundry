<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use HasFactory;

    // Define the table name if it's different from the default
    protected $table = 'categories';

    // Define which attributes can be mass assigned
    protected $fillable = [
        'name', 
        'price'
    ];

    // Define the relationships

    /**
     * Get the orders for the category.
     */
    public function orders()
    {
        return $this->hasMany(Order::class);
    }
}
