<?php

namespace App\Models;

use Laravel\Sanctum\HasApiTokens;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Traits\HasRoles;
use Tymon\JWTAuth\Contracts\JWTSubject;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable implements JWTSubject
{
    use HasApiTokens, HasFactory, Notifiable, HasRoles;

    // Guard untuk Spatie Roles
    protected $guard_name = 'api';

    /**
     * Relationship with the Profile model.
     */
    public function profile()
    {
        return $this->hasOne(Profile::class, 'user_id');
    }
    
    /**
     * Relationship with the Profiles model.
     */
    public function profiles()
    {
        return $this->hasOne(Profile::class); // Pastikan user hanya memiliki satu profil
    }
    
    /**
     * Relasi ke tabel roles.
     */
    public function role()
    {
        return $this->belongsTo(Role::class, 'role_id');
    }

    /**
     * Atribut mass assignable.
     */
    protected $fillable = [
        'username',
        'email',
        'password',
        'role_id',
        'google_id', // Tambahkan google_id
    ];

    /**
     * Atribut yang disembunyikan.
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Casting tipe data atribut.
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed', // Gunakan hashing otomatis untuk kata sandi
    ];

    /**
     * Nilai default atribut.
     */
    protected $attributes = [
        'role_id' => 2, // Role ID default untuk customer
    ];

    /**
     * Mendapatkan array izin untuk pengguna.
     */
    public function getPermissionArray()
    {
        return $this->getAllPermissions()->mapWithKeys(function ($permission) {
            return [$permission->name => true];
        });
    }

    /**
     * Mendapatkan identifier untuk JWT.
     */
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    /**
     * Mendapatkan klaim tambahan untuk JWT.
     */
    public function getJWTCustomClaims()
    {
        return [];
    }
}