<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Banner extends Model
{
    use HasFactory;

    // Tentukan tabel yang digunakan (defaultnya Laravel akan mengambil nama tabel dari plural bentuk model)
    protected $table = 'banner';

    // Tentukan kolom mana yang dapat diisi massal (mass assignable)
    protected $fillable = [
        'judul', 
        'deskripsi', 
        'gambar',
    ];
}
