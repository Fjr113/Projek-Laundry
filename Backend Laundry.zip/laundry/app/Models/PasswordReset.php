<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PasswordReset extends Model
{
    // Tentukan nama tabel jika tidak mengikuti konvensi pluralisasi
    protected $table = 'password_resets';

    // Tentukan kolom yang bisa diisi (fillable)
    protected $fillable = ['email', 'code', 'created_at'];

    // Tentukan apakah kolom timestamps (created_at, updated_at) digunakan
    public $timestamps = false;
}
