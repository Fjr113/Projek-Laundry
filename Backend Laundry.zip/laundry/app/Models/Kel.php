<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Kel extends Model
{
    use HasFactory;

    protected $table = 'kel';

    protected $fillable = [
        'kelurahan',
        'kecamatan',
        'fee',
    ];

    /**
     * Relasi dengan kec (tabel kec).
     */
    public function kec()
    {
        return $this->belongsTo(Kec::class, 'kec_id');
    }
}