<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ClaimVoucher1 extends Model
{
    use HasFactory;

    // Menentukan nama tabel secara eksplisit
    protected $table = 'claim_voucher1';  // Adjusted to match the table name

    protected $fillable = [
        'user_id',
        'voucher1_id',  // Adjusted to voucher1_id for the relationship field
        'expired',  // Adjusted to voucher2_id for the relationship field
        'status',  // Adjusted to voucher2_id for the relationship field
        'pakai', //total claim
    ];

    /**
     * Mendefinisikan relasi dengan model User
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Mendefinisikan relasi dengan model Voucher1
     */
    public function voucher1()  // Adjusted to voucher1 for the related model
    {
        return $this->belongsTo(Voucher1::class, 'voucher1_id');  // Adjusted relationship field
    }
}
