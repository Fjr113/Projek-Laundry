<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Status extends Model
{
    use HasFactory;

    // Specify the table name if it's different from the default
    protected $table = 'statuses'; 

    // Define which attributes can be mass assigned
    protected $fillable = [
        'name',
    ];

    // Define relationships if any
}
