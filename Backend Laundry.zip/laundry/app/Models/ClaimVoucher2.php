<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ClaimVoucher2 extends Model
{
    use HasFactory;

    // Menentukan nama tabel secara eksplisit
    protected $table = 'claim_voucher2';  // Adjusted to match the table name

    protected $fillable = [
        'user_id',
        'voucher2_id',  // Adjusted to voucher2_id for the relationship field
        'expired',  // Adjusted to voucher2_id for the relationship field
        'status',
        'pakai',  //total claim
    ];

    /**
     * Mendefinisikan relasi dengan model User
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Mendefinisikan relasi dengan model Voucher2
     */
    public function voucher2()  // Adjusted to voucher2 for the related model
    {
        return $this->belongsTo(Voucher2::class, 'voucher2_id');  // Adjusted relationship field
    }
}
