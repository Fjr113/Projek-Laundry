<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

    // Specify the table name if it's different from the default
    protected $table = 'orders'; 

    // Define which attributes can be mass assigned
    protected $fillable = [
        'user_id', 
        'category_id', 
        'total_price', 
        'qty',
        'name',
        'address', 
        'delivery_method_id', 
        'payment_method_id', 
        'status_id',
        'order_code',
        'kel_id', // Add kel_id to the fillable array
        'tanggal_pesan', 
        'tanggal_selesai',
        'voucher1_id',
        'voucher2_id', // Add voucher2_id to the fillable array
    ];

    // Define the relationships

    /**
     * Get the user that owns the order.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the category associated with the order.
     */
    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    /**
     * Get the delivery method associated with the order.
     */
    public function deliveryMethod()
    {
        return $this->belongsTo(DeliveryMethod::class);
    }

    /**
     * Get the payment method associated with the order.
     */
    public function paymentMethod()
    {
        return $this->belongsTo(PaymentMethod::class);
    }

    /**
     * Get the status associated with the order.
     */
    public function status()
    {
        return $this->belongsTo(Status::class, 'status_id');
    }

    /**
     * Get the kelurahan (Kel) associated with the order.
     */
    public function kel()
    {
        return $this->belongsTo(Kel::class);
    }

    /**
     * Get the voucher1 associated with the order.
     */
    public function voucher1()
    {
        return $this->belongsTo(Voucher1::class, 'voucher1_id');  // Adjusted to voucher1_id
    }

    /**
     * Get the voucher2 associated with the order.
     */
    public function voucher2()
    {
        return $this->belongsTo(Voucher2::class, 'voucher2_id');  // Adjusted to voucher2_id
    }
}
