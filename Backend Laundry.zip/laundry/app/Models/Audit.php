<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Audit extends Model
{
    use HasFactory;

    // Nama tabel
    protected $table = 'audit';

    // Kolom yang bisa diisi secara massal
    protected $fillable = [
        'user_id',
        'action',
        'created_at',
        'description',
    ];

    // Menonaktifkan kolom timestamps (updated_at)
    public $timestamps = false;

    /**
     * Relasi ke model User.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
