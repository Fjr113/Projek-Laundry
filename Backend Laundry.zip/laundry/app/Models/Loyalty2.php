<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Loyalty2 extends Model
{
    use HasFactory;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'loyalty2';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'loyalty_id',
        'user_id',
        'expired',
    ];

    /**
     * Get the related loyalty record.
     */
    public function loyalty()
    {
        return $this->belongsTo(Loyalty::class, 'loyalty_id');
    }

    /**
     * Get the related user record.
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
