<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Voucher1 extends Model
{
    use HasFactory;

    // Menentukan nama tabel secara eksplisit
    protected $table = 'voucher1';

    // Tambahkan 'min' dan 'max' ke dalam $fillable
    protected $fillable = [
        'nama',
        'harga',
        'qty',
        'min',
        'max',
    ];

    /**
     * Fungsi untuk mengurangi kuantitas voucher saat klaim
     */
    public function decreaseQuantity()
    {
        if ($this->qty > 0) {
            $this->decrement('qty');
        }
    }
}

