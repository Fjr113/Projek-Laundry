<?php

namespace App\Events;

use App\Models\Message;
use Illuminate\Broadcasting\Channel;
use Illuminate\Queue\SerializesModels;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;

class MessageSent implements ShouldBroadcast
{
    use InteractsWithSockets, SerializesModels;

    public $message;

    /**
     * Buat instance event baru.
     *
     * @param  \App\Models\Message  $message
     * @return void
     */
    public function __construct(Message $message)
    {
        $this->message = $message;
    }

    /**
     * Tentukan channel yang akan digunakan untuk broadcast.
     *
     * @return \Illuminate\Broadcasting\Channel
     */
    public function broadcastOn()
    {
        // Tentukan channel dinamis berdasarkan pengirim dan penerima
        $senderChannel = 'chat.' . $this->message->sender_id;
        $receiverChannel = 'chat.' . $this->message->receiver_id;

        // Admin bisa berada di kedua channel
        return [
            new Channel($senderChannel),
            new Channel($receiverChannel),
        ];
    }

    /**
     * Data yang akan dikirimkan melalui broadcast.
     *
     * @return array
     */
    public function broadcastWith()
    {
        // Mengirimkan data pesan yang diperlukan melalui broadcast
        return [
            'id' => $this->message->id,
            'sender_id' => $this->message->sender_id,
            'receiver_id' => $this->message->receiver_id,
            'message' => $this->message->message,
            'created_at' => $this->message->created_at->toDateTimeString(),
            'sender_name' => $this->message->sender->username, // Menambahkan nama pengirim
            'receiver_name' => $this->message->receiver->username, // Menambahkan nama penerima
        ];
    }
}
