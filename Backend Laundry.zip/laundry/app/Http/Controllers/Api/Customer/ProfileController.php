<?php

namespace App\Http\Controllers\Api\Customer;

use App\Http\Controllers\Controller;
use App\Models\Profile;
use App\Models\Loyalty2;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;

class ProfileController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // Menampilkan semua profil milik user yang login beserta relasi dari tabel terkait
        $profiles = Profile::with(['user']) // Memuat relasi ke tabel user
            ->where('user_id', Auth::id())
            ->get();

        // Menambahkan URL untuk avatar di setiap profil
        $profiles->each(function ($profile) {
            if ($profile->avatar) {
                $profile->avatar = url('storage/' . $profile->avatar);
            }
        });

        return response()->json([
            'message' => 'Profiles retrieved successfully',
            'data' => $profiles
        ]);
    }

    /**
     * Store a newly created resource in storage.
     * Membatasi agar user hanya bisa membuat 1 profil
     */
    public function store(Request $request)
{
    // Cek apakah user sudah memiliki profil
    if (Profile::where('user_id', Auth::id())->exists()) {
        return response()->json(['message' => 'You can only create one profile. Please update your existing profile instead.'], 400);
    }

    // Validasi data yang diterima
    $validated = $request->validate([
        'nama' => 'required|string|max:255',
        'no_hp' => 'required|string|max:15',
        'jenis_kelamin' => 'required|string|in:Laki-Laki,Perempuan',
        'avatar' => 'nullable|file|mimes:jpeg,png,jpg|max:2048',
        'lahir' => 'required|date',
    ]);

    // Upload file avatar jika ada
    if ($request->hasFile('avatar')) {
        $validated['avatar'] = $request->file('avatar')->store('avatars', 'public');
    }

    // Tambahkan user_id dari pengguna yang login
    $validated['user_id'] = Auth::id();

    // Simpan profil ke database
    $profile = Profile::create($validated);

    // Tambahkan data ke tabel loyalty2
    Loyalty2::create([
        'loyalty_id' => 1, // Default loyalty_id = 1
        'user_id' => Auth::id(),
        'expired' => Carbon::now()->addMonth()->format('Y-m-d'), // Simpan dalam format Y-m-d
    ]);

    // Jika avatar ada, tambahkan URL avatar ke respons
    if ($profile->avatar) {
        $profile->avatar = Storage::url($profile->avatar);
    }

    return response()->json([
        'message' => 'Profile created successfully',
        'data' => $profile
    ]);
}


    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        // Menampilkan profil berdasarkan ID jika milik user yang login
        $profile = Profile::with('user') // Memuat relasi ke tabel user
            ->where('id', $id)
            ->where('user_id', Auth::id())
            ->firstOrFail();

        // Menambahkan URL untuk avatar jika ada
        if ($profile->avatar) {
            $profile->avatar = url('storage/' . $profile->avatar);
        }

        return response()->json([
            'message' => 'Profile retrieved successfully',
            'data' => $profile
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        // Cari profil milik user yang login
        $profile = Profile::where('id', $id)->where('user_id', Auth::id())->firstOrFail();

        // Validasi data yang diterima
        $validated = $request->validate([
            'nama' => 'nullable|string|max:255',
            'no_hp' => 'nullable|string|max:15',
            'jenis_kelamin' => 'nullable|string|in:Laki-Laki,Perempuan',
            'avatar' => 'nullable|file|mimes:jpeg,png,jpg|max:2048', // Validasi file
            'lahir' => 'nullable|date', // Validasi tanggal lahir
        ]);

        // Upload file avatar jika ada
        if ($request->hasFile('avatar')) {
            // Hapus avatar lama jika ada
            if ($profile->avatar) {
                Storage::disk('public')->delete($profile->avatar);
            }
            $validated['avatar'] = $request->file('avatar')->store('avatars', 'public');
        }

        // Update profil
        $profile->update($validated);

        // Jika avatar ada, tambahkan URL avatar ke respons
        if ($profile->avatar) {
            $profile->avatar = Storage::url($profile->avatar);  // Gantikan avatar dengan URL gambar
        }

        return response()->json(['message' => 'Profile updated successfully', 'data' => $profile]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        // Cari profil milik user yang login
        $profile = Profile::where('id', $id)->where('user_id', Auth::id())->firstOrFail();

        // Hapus avatar jika ada
        if ($profile->avatar) {
            Storage::disk('public')->delete($profile->avatar);
        }

        // Hapus profil
        $profile->delete();

        return response()->json(['message' => 'Profile deleted successfully']);
    }

    /**
     * Remove the avatar from the specified profile.
     */
    public function removeAvatar($id)
    {
        // Cari profil milik user yang login
        $profile = Profile::where('id', $id)->where('user_id', Auth::id())->firstOrFail();

        // Cek jika profil memiliki avatar
        if ($profile->avatar) {
            // Hapus avatar dari penyimpanan
            Storage::disk('public')->delete($profile->avatar);

            // Set avatar menjadi null di database
            $profile->avatar = null;
            $profile->save();

            return response()->json(['message' => 'Avatar removed successfully']);
        }

        return response()->json(['message' => 'No avatar found to remove'], 404);
    }
}
