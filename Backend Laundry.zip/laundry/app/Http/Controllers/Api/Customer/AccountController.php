<?php

namespace App\Http\Controllers\Api\Customer;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class AccountController extends Controller
{
    /**
     * Update the logged-in user's account details (username, email, password).
     */
    public function update(Request $request)
    {
        // Get the currently authenticated user
        $user = Auth::user();

        // Validate the incoming request
        $validated = $request->validate([
            'username' => [
                'nullable', 
                'string', 
                'max:255', 
                Rule::unique('users')->ignore($user->id)
            ], // Username should be unique but not for the current user
            'email' => [
                'nullable', 
                'string', 
                'email', 
                'max:255', 
                Rule::unique('users')->ignore($user->id)
            ], // Email should be unique but not for the current user
            'password' => 'nullable|string|min:8|confirmed', // Password validation
        ]);

        // Update the username if provided
        if ($request->has('username')) {
            $user->username = $validated['username'];
        }

        // Update the email if provided
        if ($request->has('email')) {
            $user->email = $validated['email'];
        }

        // Update the password if provided
        if ($request->has('password')) {
            // Hash the new password before saving it
            $user->password = Hash::make($validated['password']);
        }

        // Save the updated user data
        $user->save();

        return response()->json(['message' => 'Account updated successfully', 'data' => $user]);
    }
}

