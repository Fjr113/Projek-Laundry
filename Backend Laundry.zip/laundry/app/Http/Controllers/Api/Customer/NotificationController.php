<?php

namespace App\Http\Controllers\Api\Customer;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class NotificationController extends Controller
{
    /**
     * Get all notifications for the authenticated user.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        // Get the authenticated user
        $user = Auth::user();

        // Retrieve the notifications for the user
        $notifications = Notification::where('user_id', $user->id)
            ->orderBy('created_at', 'desc') // Order by most recent
            ->get();

        // Return the notifications as a JSON response
        return response()->json([
            'success' => true,
            'notifications' => $notifications,
        ]);
    }

    /**
     * Delete a notification for the authenticated user.
     *
     * @param int $notificationId
     * @return \Illuminate\Http\JsonResponse
     */
    public function delete($notificationId)
    {
        // Get the notification by ID
        $notification = Notification::where('user_id', Auth::id())
            ->where('id', $notificationId)
            ->firstOrFail();

        // Delete the notification
        $notification->delete();

        // Return a success response
        return response()->json([
            'success' => true,
            'message' => 'Notification deleted.',
        ]);
    }
}
