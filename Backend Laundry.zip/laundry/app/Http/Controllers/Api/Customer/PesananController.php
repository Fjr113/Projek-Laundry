<?php

namespace App\Http\Controllers\Api\Customer;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Loyalty2; // Assuming this is the loyalty level model
use App\Models\Loyalty;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class PesananController extends Controller
{
    public function index()
    {
        $orders = Order::with(['status', 'category', 'paymentMethod', 'deliveryMethod', 'kel.kec'])
            ->where('user_id', Auth::id())
            ->get();

        return response()->json([
            'success' => true,
            'orders' => $orders,
        ]);
    }

    public function show($id)
    {
        $order = Order::with(['status', 'category', 'paymentMethod', 'deliveryMethod', 'kel.kec'])
            ->findOrFail($id);

        return response()->json([
            'success' => true,
            'order' => $order,
        ]);
    }

    /**
     * Update the status of an order.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function updateStatus(Request $request, $id)
    {
        // Find the order by ID and ensure it's the user's order
        $order = Order::where('id', $id)->where('user_id', Auth::id())->firstOrFail();

        // Handle status change to 5 (special condition)
        if ($request->status_id == 5) {
            // Ensure the current status is 1
            if ($order->status_id != 1) {
                return response()->json([
                    'success' => false,
                    'message' => 'The status can only be updated to 5 if it is currently 1.',
                ], 400);
            }

            // Ensure the order's status is not already 5
            if ($order->status_id == 5) {
                return response()->json([
                    'success' => false,
                    'message' => 'The status is already 5 and cannot be changed further.',
                ], 400);
            }

            // Update the order's status to 5
            $order->status_id = 5;
            $order->save();

            return response()->json([
                'success' => true,
                'message' => 'Order status successfully updated to 5.',
                'order' => $order,
            ]);
        }

        // Handle status change to 4 (completed)
        if ($order->status_id != 3) {
            return response()->json([
                'success' => false,
                'message' => 'The status can only be updated to 4 if it is currently 3.',
            ], 400);
        }

        if ($order->status_id == 4) {
            return response()->json([
                'success' => false,
                'message' => 'The order status is already 4 and cannot be changed further.',
            ], 400);
        }

        $order->status_id = 4;

        if ($order->tanggal_selesai === null) {
            $order->tanggal_selesai = Carbon::now()->locale('id')->translatedFormat('d F Y, H:i:s');
        }

        $order->save();

        $completedOrdersCount = Order::where('user_id', Auth::id())
            ->where('status_id', 4)
            ->count();

        $newLoyaltyLevel = $this->getLoyaltyLevel($completedOrdersCount);

        $loyaltyRecord = Loyalty2::where('user_id', Auth::id())->first();

        if (!$loyaltyRecord) {
            // Jika tidak ada catatan loyalti sebelumnya, buat baru
            $loyaltyRecord = new Loyalty2();
            $loyaltyRecord->user_id = Auth::id();
            $loyaltyRecord->loyalty_id = $newLoyaltyLevel->id;
            $loyaltyRecord->expired = Carbon::now()->addMonth()->format('Y-m-d'); // Format ke Y-m-d
            $loyaltyRecord->save();
        } else {
            // Jika ada catatan loyalti sebelumnya, perbarui
            if ($newLoyaltyLevel->nama == 'Supreme') {
                $extraWeeks = floor(($completedOrdersCount - 35) / 5);
                $loyaltyRecord->expired = Carbon::parse($loyaltyRecord->expired)
                    ->addWeeks($extraWeeks)
                    ->format('Y-m-d'); // Format ke Y-m-d
            } else {
                $loyaltyRecord->loyalty_id = $newLoyaltyLevel->id;
                $loyaltyRecord->expired = Carbon::parse($loyaltyRecord->expired)
                    ->addMonth()
                    ->format('Y-m-d'); // Format ke Y-m-d
            }
        
            $loyaltyRecord->save();
        }
        
        
        

        return response()->json([
            'success' => true,
            'message' => 'Order status updated and loyalty level upgraded successfully.',
            'order' => $order,
            'new_loyalty_level' => $newLoyaltyLevel->nama,
            'new_expiration' => $loyaltyRecord->expired,
        ]);
    }

    /**
     * Get the loyalty level based on completed orders.
     *
     * @param int $completedOrdersCount
     * @return \App\Models\Loyalty
     */
    private function getLoyaltyLevel($completedOrdersCount)
    {
        // Define the loyalty levels based on completed orders
        if ($completedOrdersCount >= 50) {
            return Loyalty::where('nama', 'Supreme')->first();
        } elseif ($completedOrdersCount >= 40) {
            return Loyalty::where('nama', 'Majestic')->first();
        } elseif ($completedOrdersCount >= 30) {
            return Loyalty::where('nama', 'Luxury')->first();
        } elseif ($completedOrdersCount >= 20) {
            return Loyalty::where('nama', 'Elegant')->first();
        } elseif ($completedOrdersCount >= 10) {
            return Loyalty::where('nama', 'Flawless')->first();
        } else {
            return Loyalty::where('nama', 'Fresh')->first();
        }
    }
    
}
