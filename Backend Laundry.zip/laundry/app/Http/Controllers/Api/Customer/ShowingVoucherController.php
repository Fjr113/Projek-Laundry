<?php

namespace App\Http\Controllers\Api\Customer;

use App\Http\Controllers\Controller;
use App\Models\ClaimVoucher1;
use App\Models\ClaimVoucher2;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;

class ShowingVoucherController extends Controller
{
    /**
     * Menampilkan semua claim voucher1 berdasarkan ID pengguna yang sedang login
     *
     * @return JsonResponse
     */
    public function showAllClaimVoucher1(): JsonResponse
    {
        $claimVouchers1 = ClaimVoucher1::with(['user', 'voucher1'])
            ->where('user_id', Auth::id()) // Filter berdasarkan ID pengguna yang sedang login
            ->get();

        return response()->json([
            'success' => true,
            'data' => $claimVouchers1,
        ]);
    }

    /**
     * Menampilkan semua claim voucher2 berdasarkan ID pengguna yang sedang login
     *
     * @return JsonResponse
     */
    public function showAllClaimVoucher2(): JsonResponse
    {
        $claimVouchers2 = ClaimVoucher2::with(['user', 'voucher2'])
            ->where('user_id', Auth::id()) // Filter berdasarkan ID pengguna yang sedang login
            ->get();

        return response()->json([
            'success' => true,
            'data' => $claimVouchers2,
        ]);
    }
}
