<?php

namespace App\Http\Controllers\Api\Customer;

use App\Http\Controllers\Controller;
use App\Models\ClaimVoucher1;
use App\Models\Voucher1;
use App\Models\Loyalty2;
use App\Models\Audit; // Corrected model name
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class ClaimVoucher1Controller extends Controller
{
    /**
     * Menampilkan semua voucher yang dapat diklaim sesuai level loyalitas.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        $loyalty = Loyalty2::where('user_id', Auth::id())->first();

        if (!$loyalty) {
            return response()->json([
                'success' => false,
                'message' => 'Loyalty data not found.',
            ], 400);
        }

        // Fetch vouchers where the voucher ID is greater than 6 (no loyalty restrictions)
        $vouchers = Voucher1::where('qty', '>', 0)
            ->where(function ($query) use ($loyalty) {
                // Vouchers with ID > 6 are always available
                $query->where('id', '>', 6)
                    // For vouchers with ID <= 6, filter by loyalty level
                    ->orWhere(function ($query) use ($loyalty) {
                        $query->where('id', '<=', $loyalty->loyalty_id);
                    });
            })
            ->get();
            
                    $this->logAudit(Auth::id(), null, 'lihat_voucher', 'Melihat voucher yang tersedia');


        return response()->json([
            'success' => true,
            'data' => $vouchers,
        ]);
    }

    /**
 * Membuat klaim voucher atau memperbarui jika statusnya inactive atau expired.
 *
 * @param \Illuminate\Http\Request $request
 * @return \Illuminate\Http\JsonResponse
 */
public function store(Request $request)
{
    $request->validate([
        'voucher1_id' => 'required|exists:voucher1,id',
    ]);

    $voucher = Voucher1::find($request->voucher1_id);
    $loyalty = Loyalty2::where('user_id', Auth::id())->first();

    if (!$loyalty) {
        return response()->json([
            'success' => false,
            'message' => 'Loyalty data not found.',
        ], 400);
    }

    // Define maximum claims based on loyalty level and voucher ID
    $maxClaims = 1; // Default max claims for voucher IDs 7 and above

    // For vouchers with ID 7 and above, maxClaims should always be 1
    if ($voucher->id >= 7) {
        $maxClaims = 1;
    }

    // Define the max claim limits based on the loyalty level and voucher ID
    if ($voucher->id == 1 && $loyalty->loyalty_id >= 1) {
        $maxClaims = 1; // Loyalty level 1 can claim voucher 1
    } elseif ($voucher->id == 2 && $loyalty->loyalty_id >= 2) {
        $maxClaims = 2; // Loyalty level 2 can claim voucher 2 up to 2 times
    } elseif ($voucher->id == 3 && $loyalty->loyalty_id >= 3) {
        $maxClaims = 3; // Loyalty level 3 can claim voucher 3 up to 3 times
    } elseif ($voucher->id == 4 && $loyalty->loyalty_id >= 4) {
        $maxClaims = 4; // Loyalty level 4 can claim voucher 4 up to 4 times
    } elseif ($voucher->id == 5 && $loyalty->loyalty_id >= 5) {
        $maxClaims = 5; // Loyalty level 5 can claim voucher 5 up to 5 times
    } elseif ($voucher->id == 6 && $loyalty->loyalty_id >= 6) {
        $maxClaims = 5; // Loyalty level 6 can claim voucher 6 up to 5 times
    }

    // Check if the user has already claimed this voucher for their loyalty level
    $existingClaim = ClaimVoucher1::where('user_id', Auth::id())
        ->where('voucher1_id', $voucher->id)
        ->first();

    if ($existingClaim) {
        // If the voucher has been claimed before (pakai == 1), it cannot be claimed again
        if ($existingClaim->pakai >= $maxClaims) {
            return response()->json([
                'success' => false,
                'message' => 'Batas klaim voucher telah tercapai.',
            ], 400);
        }

        // If the voucher is inactive or expired, update the claim data
        if ($existingClaim->status === 'inactive' || Carbon::parse($existingClaim->expired)->isPast()) {
            $existingClaim->update([
                'status' => 'active',
                'expired' => Carbon::now()->addWeek()->format('d-m-Y'), // Add 1 week
                'pakai' => $existingClaim->pakai + 1, // Increment usage count
            ]);
            
            
 // Log the audit for updating a claim
                $this->logAudit(Auth::id(), $voucher->id, 'klaim_voucher', "Klaim voucher diperbarui untuk Voucher ID: {$voucher->id}");

            return response()->json([
                'success' => true,
                'message' => 'Voucher berhasil diklaim kembali.',
            ]);
        }

        // If the voucher is still active, the claim cannot be made
        return response()->json([
            'success' => false,
            'message' => 'Voucher ini masih aktif. Gunakan voucher sebelumnya terlebih dahulu',
        ], 400);
    }

    // If no claim exists, check the user's loyalty level against the voucher requirements
    // Only apply loyalty level checks for vouchers with ID <= 6
    if ($voucher->id < 7 && $loyalty->loyalty_id < $voucher->id) {
        return response()->json([
            'success' => false,
            'message' => 'Loyalitas level anda tidak cukup untuk mengklaim voucher ini.',
        ], 400);
    }

    // If the voucher can be claimed, create a new claim
    ClaimVoucher1::create([
        'user_id' => Auth::id(),
        'voucher1_id' => $voucher->id,
        'status' => 'active',
        'expired' => Carbon::now()->addWeek()->format('d-m-Y'), // Expired in one week
        'pakai' => 1, // Set initial usage to 1 (first time)
    ]);

    // Decrement voucher quantity
    $voucher->decrement('qty');

    $this->logAudit(Auth::id(), $voucher->id, 'klaim_voucher_diskon', "Klaim Voucher ID: {$voucher->id} - Nama Voucher: {$voucher->nama}");

    return response()->json([
        'success' => true,
        'message' => 'Voucher berhasil diklaim.',
    ]);
}


    /**
     * Menampilkan voucher dengan status active milik pengguna saat ini.
     *
     * @return \Illuminate\Http\JsonResponse
     */
public function activeVouchers()
{
    $activeVouchers = ClaimVoucher1::with('voucher1')  // Tambahkan relasi voucher1
        ->where('user_id', Auth::id())
        ->where('status', 'active')
        ->get();
        
       $this->logAudit(Auth::id(), null, 'lihat_voucher_aktif', 'Melihat voucher aktif');

    return response()->json([
        'success' => true,
        'data' => $activeVouchers,
    ]);
}

    /**
     * Fungsi untuk mencatat log audit.
     *
     * @param int $userId
     * @param int $voucherId
     * @param string $action
     * @param string $description
     * @return void
     */
    private function logAudit($userId, $voucherId, $action, $description)
    {
        // Create an audit log entry
        Audit::create([
            'user_id' => $userId,
            'action' => $action,
            'description' => $description,
            'voucher_id' => $voucherId, // Optional, in case it's relevant
            'created_at' => Carbon::now(),
        ]);
    }
}