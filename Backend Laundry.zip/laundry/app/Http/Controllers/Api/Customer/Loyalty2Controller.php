<?php

namespace App\Http\Controllers\Api\Customer;

use App\Http\Controllers\Controller;
use App\Models\Loyalty2;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class Loyalty2Controller extends Controller
{
    /**
     * Menampilkan semua data loyalty yang valid untuk user yang login.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        $userId = Auth::id();
        $today = Carbon::now()->format('Y-m-d'); // Gunakan format Y-m-d untuk pengecekan di database

        // Ambil data loyalty yang belum expired untuk user yang login
        $loyalties = Loyalty2::where('user_id', $userId)
            ->where('expired', '>', $today) // Pastikan tanggal belum expired
            ->get();

        if ($loyalties->isEmpty()) {
            return response()->json([
                'success' => false,
                'message' => 'Tidak ada data loyalty yang valid atau semua sudah expired.',
            ], 404);
        }

        // Ubah format tanggal expired menjadi d-m-Y untuk ditampilkan
        $loyalties = $loyalties->map(function ($loyalty) {
            $loyalty->expired = Carbon::parse($loyalty->expired)->format('d-m-Y'); // Format ke d-m-Y
            return $loyalty;
        });

        return response()->json([
            'success' => true,
            'data' => $loyalties,
        ]);
    }

    /**
     * Menampilkan detail loyalty tertentu untuk user yang login.
     *
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function show($id)
    {
        $userId = Auth::id();
        $today = Carbon::now()->format('Y-m-d'); // Gunakan format Y-m-d untuk pengecekan di database

        // Cari data loyalty berdasarkan ID untuk user yang login dan belum expired
        $loyalty = Loyalty2::where('user_id', $userId)
            ->where('id', $id)
            ->where('expired', '>', $today) // Pastikan tanggal belum expired
            ->first();

        if (!$loyalty) {
            return response()->json([
                'success' => false,
                'message' => 'Data loyalty tidak ditemukan atau sudah expired.',
            ], 404);
        }

        // Ubah format tanggal expired menjadi d-m-Y untuk ditampilkan
        $loyalty->expired = Carbon::parse($loyalty->expired)->format('d-m-Y'); // Format ke d-m-Y

        return response()->json([
            'success' => true,
            'data' => $loyalty,
        ]);
    }
}
