<?php

namespace App\Http\Controllers\Api\Customer;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Order;
use App\Models\DeliveryMethod;
use App\Models\PaymentMethod;
use App\Models\Kel;
use App\Models\Voucher1;
use App\Models\ClaimVoucher1;
use App\Models\Voucher2;
use App\Models\ClaimVoucher2;
use App\Models\Notification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Carbon\Carbon;

class CheckoutController extends Controller
{
    public function checkout(Request $request)
    {
        // Validasi data request
        $request->validate([
            'category_id' => 'required|exists:categories,id',
            'kel_id' => [
                'nullable',
                'exists:kel,id',
                function ($attribute, $value, $fail) use ($request) {
                    if ($request->delivery_method_id == 2 && empty($value)) {
                        $fail('The kelurahan field is required for delivery.');
                    }
                },
            ],
            'qty' => 'required|integer|min:1',
            'delivery_method_id' => 'required|exists:delivery_methods,id',
            'payment_method_id' => 'required|exists:payment_methods,id',
            'name' => 'required|string|max:255',
            'address' => [
                'nullable',
                'string',
                'max:255',
                function ($attribute, $value, $fail) use ($request) {
                    if ($request->delivery_method_id == 2 && empty($value)) {
                        $fail('The address field is required for delivery.');
                    }
                },
            ],
            'voucher1_id' => 'nullable|exists:voucher1,id',
            'voucher2_id' => 'nullable|exists:voucher2,id',
        ]);

        // Ambil data terkait
        $category = Category::findOrFail($request->category_id);
        $deliveryMethod = DeliveryMethod::findOrFail($request->delivery_method_id);
        $paymentMethod = PaymentMethod::findOrFail($request->payment_method_id);
        $kel = $request->kel_id ? Kel::findOrFail($request->kel_id) : null;

        // Hitung harga produk
        $price = $category->price;
        $productTotal = $price * $request->qty;
        
        // Inisialisasi biaya pengiriman
        $deliveryFee = 0;
        if ($deliveryMethod->id == 2 && $kel) {
            $deliveryFee = $kel->fee;
        }

        // Total sebelum diskon
        $totalPrice = $productTotal + $deliveryFee;
        
        $voucher1 = null;
        $voucher2 = null;
        $finalDeliveryFee = $deliveryFee;

        // Proses Voucher 2 (free ongkir) terlebih dahulu
        if ($request->voucher2_id) {
            $voucher2 = Voucher2::find($request->voucher2_id);
            $claimVoucher2 = ClaimVoucher2::where('user_id', Auth::id())
                ->where('voucher2_id', $voucher2->id)
                ->where('status', 'active')
                ->first();

            if (!$claimVoucher2 || Carbon::parse($claimVoucher2->expired)->isPast()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Voucher2 tidak valid atau telah expired.',
                ], 400);
            }

            if ($kel && isset($kel->fee)) {
                $voucher2Discount = (float) $voucher2->harga;
                $finalDeliveryFee = max(0, $deliveryFee - $voucher2Discount);
                $totalPrice = $productTotal + $finalDeliveryFee;

                $claimVoucher2->update(['status' => 'inactive']);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Kelurahan tidak ditemukan atau fee tidak tersedia.',
                ], 400);
            }
        }

        // Proses Voucher 1 (persentase diskon) setelah ongkir dihitung
        if ($request->voucher1_id) {
            $voucher1 = Voucher1::find($request->voucher1_id);
            
            $voucher1Harga = is_numeric($voucher1->harga) ? (float) $voucher1->harga : 0;
            $voucher1Max = is_numeric($voucher1->max) ? (float) $voucher1->max : 0;
            $voucher1Min = is_numeric($voucher1->min) ? (float) $voucher1->min : 0;
            
            $claimVoucher1 = ClaimVoucher1::where('user_id', Auth::id())
                ->where('voucher1_id', $voucher1->id)
                ->where('status', 'active')
                ->first();
            
            if (!$claimVoucher1 || Carbon::parse($claimVoucher1->expired)->isPast()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Voucher1 tidak valid atau telah expired.',
                ], 400);
            }
            
            if ($productTotal >= $voucher1Min) {
                // Hitung diskon berdasarkan harga produk saja (tidak termasuk ongkir)
                $voucher1Discount = ($productTotal * $voucher1Harga) / 100;
                $voucher1Discount = min($voucher1Discount, $voucher1Max);
                
                // Update total price dengan menambahkan ongkir setelah diskon
                $totalPrice = ($productTotal - $voucher1Discount) + $finalDeliveryFee;
                
                $claimVoucher1->update(['status' => 'inactive']);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Total belanja tidak memenuhi syarat untuk menggunakan Voucher1.',
                ], 400);
            }
        }

        // Buat order
        $orderCode = Str::random(10);
        $statusId = 1; // Belum bayar
        $tanggalPesan = Carbon::now()->locale('id')->translatedFormat('d F Y, H:i:s');

        $order = Order::create([
            'user_id' => Auth::id(),
            'category_id' => $category->id,
            'kel_id' => $kel ? $kel->id : null,
            'total_price' => $totalPrice,
            'qty' => $request->qty,
            'delivery_method_id' => $deliveryMethod->id,
            'payment_method_id' => $paymentMethod->id,
            'status_id' => $statusId,
            'name' => $request->name,
            'address' => $deliveryMethod->id == 2 ? $request->address : null,
            'order_code' => $orderCode,
            'tanggal_pesan' => $tanggalPesan,
            'tanggal_selesai' => null,
            'voucher1_id' => $voucher1 ? $voucher1->id : null,
            'voucher2_id' => $voucher2 ? $voucher2->id : null,
        ]);

        // Kirim notifikasi untuk admin
        Notification::create([
            'user_id' => 1,
            'order_id' => $order->id,
            'message' => 'Pesanan baru dari ' . Auth::user()->username . '. Order ID: ' . $order->order_code,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Order created successfully',
            'order' => $order,
        ], 201);
    }
}