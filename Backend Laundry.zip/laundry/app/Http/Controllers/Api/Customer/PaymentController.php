<?php

namespace App\Http\Controllers\Api\Customer;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Midtrans\Snap;
use Midtrans\Config;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PaymentController extends Controller
{
    public function __construct()
    {
        // Initialize the Midtrans configuration directly in the controller
        $isSandbox = true;  // Set to false if you're using the production environment

        Config::$serverKey = 'SB-Mid-server-ReWSzWWea1cnrN0eQW9SZ6Rb';  // Set your server key here
        Config::$clientKey = 'SB-Mid-client-blaFJdTCAl7aH8Em';  // Set your client key here
        Config::$isProduction = !$isSandbox;
        Config::$isSanitized = true;
        Config::$is3ds = true;
    }

    /**
     * Generate Snap token for payment
     *
     * @param int $orderId
     * @return \Illuminate\Http\JsonResponse
     */
    public function generateSnapToken($orderId)
    {
        // Find the order by ID
        $order = Order::findOrFail($orderId);

        // Check if the payment_method_id is not 2
        if ($order->payment_method_id != 2) {
            return response()->json([
                'error' => 'Payment token cannot be generated for orders with a payment method other than 2.',
                'message' => 'Order payment method is not eligible for payment.',
            ], 400);
        }

        // Get the authenticated user's details
        $username = Auth::user()->username;
        $email = Auth::user()->email;
        $phone = Auth::user()->phone;  // Assuming the phone number is stored in the user model

        // Prepare the transaction details for Midtrans
        $transactionDetails = [
            'order_id' => $order->order_code,  // Use order code for unique identification
            'gross_amount' => $order->total_price,  // Total price of the order
        ];

        // Prepare customer details
        $customerDetails = [
            'first_name' => $username,  // Use username as first name
            'email' => $email,  // Use the customer's email
            'phone' => $phone,  // Use the customer's phone
        ];

        // Prepare item details (subtotal instead of qty)
        $itemDetails = [
            [
                'id' => $order->category_id,  // Category ID as item ID
                'name' => $order->category->name,  // Category name as item name
                'price' => $order->total_price,  // Total price for the order
                'quantity' => 1,  // Fixed to 1 since qty is removed
            ]
        ];

        // Complete transaction data for Midtrans
        $params = [
            'transaction_details' => $transactionDetails,
            'item_details' => $itemDetails,
            'customer_details' => $customerDetails,
        ];

        try {
            // Create the payment token using Midtrans Snap API
            $snapToken = Snap::getSnapToken($params);

            // Construct the Midtrans payment URL for testing
            $paymentUrl = "https://app.sandbox.midtrans.com/snap/v2/transactions/" . $snapToken;

            // Return the snap token and additional customer info along with the payment URL
            return response()->json([
                'success' => true,
                'token' => $snapToken,
                'message' => 'Payment token generated successfully.',
                'customer_name' => $username,  // Customer's name
                'customer_email' => $email,  // Customer's email
                'total_price' => $order->total_price,  // Total price of the order
                'payment_url' => $paymentUrl,  // URL for the user to test payment
            ]);
        } catch (\Exception $e) {
            // Handle any errors that occur during token generation
            return response()->json([
                'error' => 'Error generating payment token.',
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    /**
 * Handle Midtrans payment callback
 *
 * @param Request $request
 * @return \Illuminate\Http\JsonResponse
 */
  public function callback(Request $request)
    {
        try {
            // Get notification from raw POST request
            $notificationBody = json_decode($request->getContent(), true);
            
            // Log notification for debugging
            Log::info('Midtrans Notification', [
                'notification' => $notificationBody
            ]);

            if (!$notificationBody) {
                throw new \Exception('Invalid notification body');
            }

            // Find the order by order_code
            $order = Order::where('order_code', $notificationBody['order_id'])->first();
            
            if (!$order) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Order not found'
                ], 404);
            }

            // Get transaction status
            $transactionStatus = $notificationBody['transaction_status'] ?? null;

            // Handle different transaction statuses
            switch ($transactionStatus) {
                case 'capture':
                    $fraudStatus = $notificationBody['fraud_status'] ?? null;
                    if ($fraudStatus == 'accept') {
                        $order->status_id = 2; // Update to "Diproses" status
                    }
                    break;
                    
                case 'settlement':
                    $order->status_id = 2; // Update to "Diproses" status
                    break;
                    
                case 'pending':
                    // Keep current status
                    break;
                    
                case 'deny':
                case 'expire':
                case 'cancel':
                    // You might want to update to a failed/cancelled status if needed
                    break;
            }

            // Save the order changes
            $order->save();

            // Return success response
            return response()->json([
                'status' => 'success',
                'message' => 'Callback processed successfully',
                'data' => [
                    'order_id' => $notificationBody['order_id'],
                    'transaction_status' => $transactionStatus
                ]
            ]);

        } catch (\Exception $e) {
            // Log the error
            Log::error('Midtrans Callback Error', [
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'request' => $request->all()
            ]);
            
            return response()->json([
                'status' => 'error',
                'message' => 'Error processing payment notification',
                'error' => $e->getMessage()
            ], 500);
        }
    }


}