<?php

namespace App\Http\Controllers\Api\Customer;

use App\Http\Controllers\Controller;
use App\Models\Loyalty;
use Illuminate\Http\Request;

class LoyaltyController extends Controller
{
    /**
     * Display a listing of all loyalty data.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        // Ambil semua data dari tabel loyalty
        $loyalties = Loyalty::all();

        // Kembalikan response dalam bentuk JSON
        return response()->json([
            'success' => true,
            'data' => $loyalties,
        ]);
    }

    /**
     * Display a specific loyalty item by ID.
     *
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function show($id)
    {
        // Cari data loyalty berdasarkan ID
        $loyalty = Loyalty::find($id);

        // Jika data tidak ditemukan, kembalikan error
        if (!$loyalty) {
            return response()->json([
                'success' => false,
                'message' => 'Loyalty data not found',
            ], 404);
        }

        // Kembalikan response dengan data loyalty
        return response()->json([
            'success' => true,
            'data' => $loyalty,
        ]);
    }
}
