<?php

namespace App\Http\Controllers\Api\Customer;

use App\Http\Controllers\Controller;
use App\Models\Rating;
use App\Models\Order;
use App\Models\User;
use App\Models\Profile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class RatingController extends Controller
{
    /**
     * Display all ratings or a specific rating by ID.
     *
     * @param \Illuminate\Http\Request $request
     * @param int|null $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function index(Request $request, $id = null)
    {
        // Check if an ID is provided
        if ($id) {
            // Find the specific rating by ID with the related user and order categories
            $rating = Rating::with(['user.profile', 'order.category'])->find($id);

            if (!$rating) {
                return response()->json([
                    'success' => false,
                    'message' => 'Rating not found.',
                ], 404);
            }

            // Add additional info
            $rating->user_username = $rating->user->username;  // Assuming 'username' is a field in the users table
            $rating->order_category_name = $rating->order->category->name;  // Assuming 'category' relation exists on the order model

            // Check if user has a profile and fetch avatar URL
            if ($rating->user->profile && $rating->user->profile->avatar) {
                $rating->user_avatar = url('storage/' . $rating->user->profile->avatar);
            } else {
                $rating->user_avatar = null;
            }

            return response()->json([
                'success' => true,
                'rating' => $rating,
            ]);
        }

        // Get all ratings with related user and order categories
        $ratings = Rating::with(['user.profile', 'order.category'])->get();

        // Loop through the ratings to add additional info
        foreach ($ratings as $rating) {
            $rating->user_username = $rating->user->username;
            $rating->order_category_name = $rating->order->category->name;

            // Check if user has a profile and fetch avatar URL
            if ($rating->user->profile && $rating->user->profile->avatar) {
                $rating->user_avatar = url('storage/' . $rating->user->profile->avatar);
            } else {
                $rating->user_avatar = null;
            }
        }

        return response()->json([
            'success' => true,
            'ratings' => $ratings,
        ]);
    }

    /**
     * Store a newly created rating.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(Request $request)
    {
        // Validate the request
        $request->validate([
            'order_id' => [
                'required',
                'exists:orders,id',
                function ($attribute, $value, $fail) {
                    // Check if the order belongs to the logged-in user and the status is "4" (completed)
                    $order = Order::where('id', $value)
                        ->where('user_id', Auth::id())
                        ->first();

                    if (!$order) {
                        $fail('The selected order does not belong to you.');
                    } elseif ($order->status_id !== 4) {
                        $fail('You can only rate orders with status "completed".');
                    }
                },
            ],
            'bintang' => 'required|numeric|min:1|max:5',
            'pesan' => 'required|string|max:1000',
        ]);

        // Check if the order already has a rating from the logged-in user
        $existingRating = Rating::where('order_id', $request->order_id)
            ->where('user_id', Auth::id())
            ->first();

        if ($existingRating) {
            return response()->json([
                'success' => false,
                'message' => 'You have already rated this order.',
            ], 400);
        }

        // Create the rating
        $rating = Rating::create([
            'user_id' => Auth::id(),
            'order_id' => $request->order_id,
            'bintang' => $request->bintang,
            'pesan' => $request->pesan,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Rating submitted successfully.',
            'rating' => $rating,
        ], 201);
    }

    /**
     * Update the specified rating.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(Request $request, $id)
    {
        // Validate the request
        $request->validate([
            'bintang' => 'nullable|numeric|min:1|max:5',
            'pesan' => 'nullable|string|max:1000',
        ]);

        // Find the rating
        $rating = Rating::where('id', $id)
            ->where('user_id', Auth::id())
            ->first();

        if (!$rating) {
            return response()->json([
                'success' => false,
                'message' => 'Rating not found or does not belong to you.',
            ], 404);
        }

        // Update the rating
        $rating->bintang = $request->bintang;
        $rating->pesan = $request->pesan;
        $rating->save();

        return response()->json([
            'success' => true,
            'message' => 'Rating updated successfully.',
            'rating' => $rating,
        ]);
    }
}