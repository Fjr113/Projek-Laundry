<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Ban;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Carbon\Carbon;

class BanController extends Controller
{
    /**
     * Ban a user.
     */
    public function banUser(Request $request): JsonResponse
    {
        $request->validate([
            'user_id' => 'required|exists:users,id',
            'duration' => 'required|in:1_week,1_month,3_months,6_months,forever',
            'message' => 'required|string',
        ]);

        if ($request->user_id == 1) {
            return response()->json(['message' => 'User ID 1 cannot be banned'], 403);
        }

        $durations = [
            '1_week' => Carbon::now()->addWeek(),
            '1_month' => Carbon::now()->addMonth(),
            '3_months' => Carbon::now()->addMonths(3),
            '6_months' => Carbon::now()->addMonths(6),
            'forever' => Carbon::now()->addYears(100),
        ];

        $ban = Ban::create([
            'user_id' => $request->user_id,
            'expired' => $durations[$request->duration],
            'message' => $request->message,
        ]);

        return response()->json(['message' => 'User banned successfully', 'ban' => $ban], 201);
    }

    /**
     * Unban a user.
     */
    public function unbanUser($id): JsonResponse
    {
        $ban = Ban::where('user_id', $id)->first();
        
        if (!$ban) {
            return response()->json(['message' => 'User not banned'], 404);
        }

        $ban->delete();

        return response()->json(['message' => 'User unbanned successfully']);
    }

    /**
     * Get banned users list.
     */
    public function bannedUsers(): JsonResponse
    {
        $bannedUsers = Ban::with('user')->get();
        return response()->json($bannedUsers);
    }
}