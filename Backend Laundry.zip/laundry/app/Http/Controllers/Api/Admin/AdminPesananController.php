<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;

class AdminPesananController extends Controller
{
    /**
     * Display a listing of all orders.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        // Retrieve all orders with related data
        $orders = Order::with(['status', 'category', 'paymentMethod', 'deliveryMethod', 'kel.kec'])->get();

        return response()->json([
            'success' => true,
            'orders' => $orders,
        ]);
    }

    /**
     * Display a specific order by ID.
     *
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function show($id)
    {
        // Retrieve a specific order by ID with related data
        $order = Order::with(['status', 'category', 'paymentMethod', 'deliveryMethod', 'kel.kec'])
            ->findOrFail($id);

        return response()->json([
            'success' => true,
            'order' => $order,
        ]);
    }
}
