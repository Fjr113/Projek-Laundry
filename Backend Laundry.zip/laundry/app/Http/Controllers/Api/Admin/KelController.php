<?php

namespace App\Http\Controllers\Api\Admin;

use App\Models\Kel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;

class KelController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        $kels = Kel::with('kec')->get();

        return response()->json([
            'success' => true,
            'message' => 'List Data Kel',
            'data' => $kels,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'kelurahan'    => 'required|string',
            'kecamatan'    => 'required|string',
            'fee'     => 'required|numeric',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $kel = Kel::create($request->only('kelurahan', 'kecamatan', 'fee'));

        return response()->json([
            'success' => true,
            'message' => 'Data Kel Berhasil Disimpan!',
            'data' => $kel,
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function show($id)
    {
        $kel = Kel::with('kec')->find($id);

        if (!$kel) {
            return response()->json(['success' => false, 'message' => 'Detail Data Kel Tidak Ditemukan'], 404);
        }

        return response()->json(['success' => true, 'message' => 'Detail Data Kel', 'data' => $kel]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Kel  $kel
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(Request $request, Kel $kel)
    {
        $validator = Validator::make($request->all(), [
            'kelurahan'    => 'nullable|string',
            'kecamatan'    => 'nullable|string',
            'fee'     => 'nullable|numeric',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $kel->update($request->only('kelurahan', 'kecamatan', 'fee'));

        return response()->json([
            'success' => true,
            'message' => 'Data Kel Berhasil Diupdate!',
            'data' => $kel,
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Kel  $kel
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy(Kel $kel)
    {
        $kel->delete();

        return response()->json(['success' => true, 'message' => 'Data Kel Berhasil Dihapus!']);
    }

    /**
     * Fetch data from external API
     *
     * @param string $url
     * @return \Illuminate\Http\JsonResponse
     */
    private function fetchDataFromApi($url)
    {
        $response = Http::get($url);

        return response()->json([
            'success' => $response->successful(),
            'message' => $response->successful() ? 'Data retrieved successfully' : 'Failed to retrieve data',
            'data' => $response->successful() ? $response->json() : null,
        ], $response->status());
    }

    public function getProvinces()
    {
        return $this->fetchDataFromApi('https://alamat.thecloudalert.com/api/provinsi/get/');
    }

    public function getCities($provinceId)
    {
        return $this->fetchDataFromApi("https://alamat.thecloudalert.com/api/kabkota/get/?d_provinsi_id={$provinceId}");
    }

    public function getDistricts($cityId)
    {
        return $this->fetchDataFromApi("https://alamat.thecloudalert.com/api/kecamatan/get/?d_kabkota_id={$cityId}");
    }

    public function getVillages($districtId)
    {
        return $this->fetchDataFromApi("https://alamat.thecloudalert.com/api/kelurahan/get/?d_kecamatan_id={$districtId}");
    }

    public function getPostalCodes($cityId, $districtId)
    {
        return $this->fetchDataFromApi("https://alamat.thecloudalert.com/api/kodepos/get/?d_kabkota_id={$cityId}&d_kecamatan_id={$districtId}");
    }

    public function searchLocation($keyword)
    {
        return $this->fetchDataFromApi("https://alamat.thecloudalert.com/api/cari/index/?keyword={$keyword}");
    }
}