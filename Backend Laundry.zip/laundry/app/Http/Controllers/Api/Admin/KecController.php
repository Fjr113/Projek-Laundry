<?php

namespace App\Http\Controllers\Api\Admin;

use App\Models\Kec;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;

class KecController extends Controller
{
    /**
 * Display a listing of the resource.
 *
 * @return \Illuminate\Http\Response
 */
public function index()
{
    $kecs = Kec::with('kel') // Muat relasi kel (sesuai kebutuhan)
        ->get(); // Ambil semua data tanpa filter

    return response()->json([
        'success' => true,
        'message' => 'List Data Kecamatan',
        'data' => $kecs,
    ]);
}


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'nama' => 'required|unique:kec,nama',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $kec = Kec::create($request->only('nama'));

        return response()->json([
            'success' => true,
            'message' => 'Data Kecamatan Berhasil Disimpan!',
            'data' => $kec,
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $kec = Kec::find($id);

        if ($kec) {
            return response()->json([
                'success' => true,
                'message' => 'Detail Data Kecamatan',
                'data' => $kec,
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Detail Data Kecamatan Tidak Ditemukan',
        ], 404);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Kec  $kec
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Kec $kec)
    {
        $validator = Validator::make($request->all(), [
            'nama' => 'required|unique:kec,nama,' . $kec->id,
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $kec->update($request->only('nama'));

        return response()->json([
            'success' => true,
            'message' => 'Data Kecamatan Berhasil Diupdate!',
            'data' => $kec,
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Kec  $kec
     * @return \Illuminate\Http\Response
     */
    public function destroy(Kec $kec)
    {
        // Hapus semua kel terkait
        $kec->kels()->delete();

        if ($kec->delete()) {
            return response()->json([
                'success' => true,
                'message' => 'Data Kecamatan Berhasil Dihapus!',
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Data Kecamatan Gagal Dihapus!',
        ], 500);
    }
}
