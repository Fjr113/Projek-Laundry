<?php

namespace App\Http\Controllers\Api\Admin;

use App\Models\LaundryStore;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Resources\LaundryStoreResource;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class LaundryStoreController extends Controller
{
    /**
     * Display a listing of the resource.
     * 
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $laundryStores = LaundryStore::when(request()->search, function($query) {
            $query->where('title', 'like', '%' . request()->search . '%');
        })->latest()->paginate(5);

        $laundryStores->appends(['search' => request()->search]);

        return new LaundryStoreResource(true, 'List Data Laundry Stores', $laundryStores);
    }

    /**
     * Store a newly created resource in storage.
     * 
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response 
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'address'       => 'required',
            'image'         => 'required|mimes:jpeg,jpg,png|max:2000',
            'title'         => 'required|unique:laundry_stores',
            'phone_num'     => 'required',
            'description'   => 'required',
            'price'         => 'required|numeric'
        ]); 

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        // Simpan gambar di 'storage/app/public/images'
        $imagePath = $request->file('image')->store('public/images');

        // Simpan data ke database
        $laundryStore = LaundryStore::create([
            'address'       => $request->address,
            'image'         => basename($imagePath), // Simpan nama file di database
            'title'         => $request->title,
            'phone_num'     => $request->phone_num,
            'description'   => $request->description,
            'price'         => $request->price,
            'rating'        => 0
        ]);

        return new LaundryStoreResource(true, 'Data Laundry Store Berhasil Disimpan!', $laundryStore);
    }

    /**
     * Display the specified resource.
     * 
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $laundryStore = LaundryStore::find($id);
        
        if ($laundryStore) {
            return new LaundryStoreResource(true, 'Detail Data Laundry Store!', $laundryStore);
        }
        
        return new LaundryStoreResource(false, 'Detail Data Laundry Store Tidak Ditemukan!', null);
    }

    /**
 * Update the specified resource in storage.
 * 
 * @param \Illuminate\Http\Request $request
 * @param \App\Models\LaundryStore $laundryStore
 * @return \Illuminate\Http\Response
 */
public function update(Request $request, LaundryStore $laundryStore)
{
    // Validasi input sesuai dengan data yang diberikan
    $validator = Validator::make($request->all(), [
        'address'       => 'sometimes|required',
        'title'         => 'sometimes|required|unique:laundry_stores,title,' . $laundryStore->id,
        'phone_num'     => 'sometimes|required',
        'description'   => 'sometimes|required',
        'price'         => 'sometimes|required|numeric',
        // Hapus validasi untuk gambar
    ]);

    if ($validator->fails()) {
        return response()->json(['errors' => $validator->errors()], 422);
    }

    // Ambil data yang diperbolehkan untuk diperbarui
    $data = $request->only(['address', 'title', 'phone_num', 'description', 'price']);

    // Update data tanpa memperbarui gambar
    $laundryStore->update($data);

    return new LaundryStoreResource(true, 'Data Laundry Store Berhasil Diupdate!', $laundryStore);
}


    /**
     * Remove the specified resource from storage.
     * 
     * @param \App\Models\LaundryStore $laundryStore
     * @return \Illuminate\Http\Response
     */
    public function destroy(LaundryStore $laundryStore)
    {
        // Hapus gambar dari storage
        Storage::delete('public/images/' . $laundryStore->image);

        if ($laundryStore->delete()) {
            return new LaundryStoreResource(true, 'Data Laundry Store Berhasil Dihapus!', null);
        }

        return new LaundryStoreResource(false, 'Data Laundry Store Gagal Dihapus!', null);
    }

    /**
     * Get all laundry stores without pagination.
     *
     * @return \Illuminate\Http\Response
     */
    public function all()
    {
        $laundryStores = LaundryStore::all();

        return response()->json($laundryStores);
    }
}
