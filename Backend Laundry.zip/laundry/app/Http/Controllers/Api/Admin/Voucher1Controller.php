<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Voucher1;  // Adjusted to Voucher1 model
use Illuminate\Http\Request;

class Voucher1Controller extends Controller
{
    /**
     * Menampilkan semua voucher.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        $vouchers = Voucher1::all();  // Mengambil semua data voucher1
        return response()->json([
            'success' => true,
            'data' => $vouchers,
        ]);
    }

    /**
     * Menyimpan voucher baru.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(Request $request)
    {
        // Validasi input
        $request->validate([
            'nama' => 'required|string|max:255',
            'harga' => 'required|string|max:255',
            'qty' => 'required|integer',
            'min' => 'required|string|max:255',
            'max' => 'required|string|max:255',
        ]);

        // Menyimpan data voucher baru
        $voucher = Voucher1::create([  // Changed to Voucher1 model
            'nama' => $request->nama,
            'harga' => $request->harga,
            'qty' => $request->qty,
            'min' => $request->min,
            'max' => $request->max,
        ]);

        return response()->json([
            'success' => true,
            'data' => $voucher,
        ], 201);
    }

    /**
     * Menampilkan detail voucher berdasarkan ID.
     *
     * @param  \App\Models\Voucher1 $voucher
     * @return \Illuminate\Http\JsonResponse
     */
    public function show(Voucher1 $voucher)  // Changed to Voucher1
    {
        return response()->json([
            'success' => true,
            'data' => $voucher,
        ]);
    }

    /**
     * Memperbarui data voucher.
     *
     * @param \Illuminate\Http\Request $request
     * @param \App\Models\Voucher1 $voucher
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(Request $request, Voucher1 $voucher)  // Changed to Voucher1
    {
        // Validasi input
        $request->validate([
            'nama' => 'required|string|max:255',
            'harga' => 'required|string|max:255',
            'qty' => 'required|integer',
            'min' => 'required|string|max:255',
            'max' => 'required|string|max:255',
        ]);

        // Memperbarui data voucher
        $voucher->update([
            'nama' => $request->nama,
            'harga' => $request->harga,
            'qty' => $request->qty,
            'min' => $request->min,
            'max' => $request->max,
        ]);

        return response()->json([
            'success' => true,
            'data' => $voucher,
        ]);
    }

    /**
     * Menghapus voucher berdasarkan ID.
     *
     * @param \App\Models\Voucher1 $voucher
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy(Voucher1 $voucher)  // Changed to Voucher1
    {
        // Menghapus voucher
        $voucher->delete();

        return response()->json([
            'success' => true,
            'message' => 'Voucher berhasil dihapus',
        ]);
    }
}
