<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Profile; // Sertakan model Profile
use Illuminate\Http\Request;

class DataAkunController extends Controller
{
    /**
     * Menampilkan daftar semua customer kecuali admin (user_id = 1).
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        // Mengambil semua user (customer) kecuali admin dengan id = 1, dan memuat hubungan role
        $users = User::where('id', '!=', 1)->with('role', 'profiles')->get();  // Memuat hubungan role dan profiles

        // Menambahkan URL avatar jika ada
        $users->each(function ($user) {
            if ($user->profiles && $user->profiles->avatar) {
                // Tambahkan URL untuk avatar
                $user->profiles->avatar = url('storage/' . $user->profiles->avatar);
            }
        });

        return response()->json([
            'success' => true,
            'data' => $users,
        ]);
    }

    /**
     * Menampilkan customer berdasarkan id.
     *
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function show($id)
    {
        // Pastikan user yang diminta bukan admin (id != 1)
        if ($id == 1) {
            return response()->json([
                'success' => false,
                'message' => 'Tidak dapat melihat akun admin.',
            ], 403);
        }

        // Mengambil user berdasarkan id yang diberikan beserta hubungan role dan profil
        $user = User::with('role', 'profiles')->find($id);

        if (!$user) {
            return response()->json([
                'success' => false,
                'message' => 'User tidak ditemukan',
            ], 404);
        }

        // Menambahkan URL avatar jika ada
        if ($user->profiles && $user->profiles->avatar) {
            $user->profiles->avatar = url('storage/' . $user->profiles->avatar);
        }

        return response()->json([
            'success' => true,
            'data' => $user,
        ]);
    }

    /**
     * Menampilkan profil dari user yang ditentukan.
     *
     * @param int $userId
     * @return \Illuminate\Http\JsonResponse
     */
    public function profile($userId)
    {
        // Pastikan user ada
        $user = User::find($userId);

        if (!$user) {
            return response()->json([
                'success' => false,
                'message' => 'User tidak ditemukan',
            ], 404);
        }

        // Mengambil profil yang terkait dengan user
        $profile = $user->profiles;

        if (!$profile) {
            return response()->json([
                'success' => false,
                'message' => 'User ini tidak memiliki profil',
            ], 404);
        }

        // Menambahkan URL untuk avatar jika ada
        if ($profile->avatar) {
            $profile->avatar = url('storage/' . $profile->avatar);
        }

        return response()->json([
            'success' => true,
            'data' => $profile,
        ]);
    }
}
