<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Audit;
use Illuminate\Http\Request;

class AuditLogController extends Controller
{
    /**
     * Menampilkan semua log audit dengan informasi user_id dan role.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        // Ambil semua log audit dengan eager loading user dan role
        $auditLogs = Audit::with(['user.role']) // Eager load user dan role
            ->orderBy('created_at', 'desc') // Urutkan berdasarkan created_at terbaru
            ->get();

        // Jika tidak ada log ditemukan
        if ($auditLogs->isEmpty()) {
            return response()->json([
                'success' => false,
                'message' => 'Tidak ada log audit ditemukan.',
            ], 404);
        }

        // Format data dengan menampilkan informasi user dan role
        $formattedLogs = $auditLogs->map(function ($auditLog) {
            return [
                'action' => $auditLog->action,
                'description' => $auditLog->description,
                'created_at' => $auditLog->created_at,
                'user' => [
                    'id' => $auditLog->user->id,
                    'username' => $auditLog->user->username,
                    'email' => $auditLog->user->email,
                    'role' => $auditLog->user->role->name, // Asumsi field name ada di tabel roles
                ],
            ];
        });

        return response()->json([
            'success' => true,
            'data' => $formattedLogs,
        ]);
    }
}
