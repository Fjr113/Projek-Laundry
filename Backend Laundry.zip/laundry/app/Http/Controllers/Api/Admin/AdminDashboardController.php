<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Order;
use App\Models\Category;
use App\Models\Karyawan;
use App\Models\Bonus;
use App\Models\Peralatan;
use App\Models\Rating;
use Carbon\Carbon;

class AdminDashboardController extends Controller
{
    /**
     * Menampilkan statistik dasbor.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        // Set lokal ke bahasa Indonesia
        Carbon::setLocale('id');

        // Statistik utama (semua data tanpa filter)
        $totalPengguna = User::count();
        $totalKategori = Category::count();
        $totalPesanan = Order::count();
        $totalKaryawan = Karyawan::count();
        $totalRating = Rating::count();

        // Total pendapatan hanya dari pesanan dengan status_id 2, 3, atau 4
        // Pesanan dengan status_id 1 (belum diproses) dan 5 (dibatalkan) tidak dihitung
        $totalPendapatan = Order::whereNotIn('status_id', [1, 5])->sum('total_price');

        // Statistik berdasarkan bulan
        $statistikBulan = [];

        // Menambahkan bulan Januari sampai Desember, bahkan jika tidak ada data untuk bulan tersebut
        $bulanTersedia = range(1, 12); // 1 hingga 12 untuk Januari - Desember
        foreach ($bulanTersedia as $bulan) {
            // Perhitungan total gaji bulanan + bonus per bulan (filter berdasarkan bulan)
            $totalGajiBulanan = Karyawan::whereMonth('created_at', $bulan)->sum('gaji');  // Ambil gaji bulanan total untuk bulan tertentu
            $totalBonus = Bonus::whereMonth('created_at', $bulan)->sum('bonusnya'); // Bonus per bulan
            $totalGajiBulanan += $totalBonus;

            // Perhitungan total harga peralatan per bulan (filter berdasarkan bulan)
            $totalBiayaPeralatan = Peralatan::whereMonth('created_at', $bulan)->sum('harga');  // Harga peralatan untuk bulan tertentu

            // Perhitungan total pengeluaran per bulan (Gaji + Peralatan)
            $totalPengeluaranBulanan = $totalGajiBulanan + $totalBiayaPeralatan;

            // Perhitungan total pendapatan per bulan dengan status_id yang valid
            $totalPendapatanBulan = Order::whereMonth('created_at', $bulan)
                ->whereNotIn('status_id', [1, 5])  // Exclude status_id 1 (belum diproses) dan 5 (dibatalkan)
                ->sum('total_price');

            // Tambahkan data bulan
            $statistikBulan[$bulan] = [
                'nama_bulan' => Carbon::create()->month($bulan)->translatedFormat('F'),  // Menggunakan nama bulan dalam bahasa Indonesia
                'total_pesanan' => Order::whereMonth('created_at', $bulan)->count(), // Menghitung semua pesanan per bulan
                'total_pendapatan' => number_format($totalPendapatanBulan, 2),  // Pendapatan bulan ini
                'total_gaji_bulanan' => number_format($totalGajiBulanan, 2),
                'total_biaya_peralatan' => number_format($totalBiayaPeralatan, 2),
                'total_pengeluaran_bulanan' => number_format($totalPengeluaranBulanan, 2),
            ];
        }

        // Statistik pesanan dibatalkan (status_id = 5)
        $pesananDibatalkan = Order::where('status_id', 5)->count();
        $pendapatanDibatalkan = Order::where('status_id', 5)->sum('total_price');

        // Perhitungan total gaji bulanan + bonus secara keseluruhan
        $totalGaji = Karyawan::sum('gaji');
        $totalBonus = Bonus::sum('bonusnya');
        $totalGajiBulanan = $totalGaji + $totalBonus;

        // Perhitungan total harga peralatan secara keseluruhan
        $totalBiayaPeralatan = Peralatan::sum('harga');

        // Perhitungan total pengeluaran secara keseluruhan (Gaji + Peralatan)
        $totalPengeluaranBulanan = $totalGajiBulanan + $totalBiayaPeralatan;

        // Hasil respon
        return response()->json([
            'success' => true,
            'data' => [
                'secara keseluruhan' => [
                    'total_pengguna' => $totalPengguna,
                    'total_kategori' => $totalKategori,
                    'total_pesanan' => $totalPesanan,
                    'total_karyawan' => $totalKaryawan,
                    'total_rating' => $totalRating,
                    'total_pendapatan' => number_format($totalPendapatan, 2),
                    'pesanan_dibatalkan' => $pesananDibatalkan,  // Menampilkan total pesanan dibatalkan
                    'pendapatan_dibatalkan' => number_format($pendapatanDibatalkan, 2),  // Menampilkan total pendapatan pesanan dibatalkan
                    'total_gaji_bulanan' => number_format($totalGajiBulanan, 2), // Menampilkan total gaji bulanan + bonus
                    'total_biaya_peralatan' => number_format($totalBiayaPeralatan, 2), // Menampilkan total harga peralatan
                    'total_pengeluaran_bulanan' => number_format($totalPengeluaranBulanan, 2), // Menampilkan total pengeluaran bulanan
                ],
                'bulanan' => array_values($statistikBulan),  // Menampilkan data bulan secara terurut tanpa bergantung pada status pesanan
            ],
        ]);
    }
}
