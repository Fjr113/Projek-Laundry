<?php

namespace App\Http\Controllers\Api\Admin;

use App\Models\Karyawan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use App\Http\Controllers\Controller;

class KaryawanController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $karyawan = Karyawan::all()->map(function ($item) {
            if ($item->foto) {
                $item->foto = url('storage/' . $item->foto);  // Mengubah foto menjadi URL publik
            }
            return $item;
        });

        return response()->json($karyawan);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama' => 'required|string|max:255',
            'alamat' => 'required|string|max:255',
            'no_ktp' => 'nullable|string|max:255',
            'gaji' => 'required|string|max:255',
            'kontrak' => 'required|date',
            'foto' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        // Handle file upload
        if ($request->hasFile('foto')) {
            $validated['foto'] = $request->file('foto')->store('karyawan', 'public');
        }

        $karyawan = Karyawan::create($validated);

        // Menambahkan URL foto ke dalam data karyawan yang baru dibuat
        if ($karyawan->foto) {
            $karyawan->foto = Storage::url($karyawan->foto);
        }

        return response()->json(['message' => 'Karyawan created successfully', 'data' => $karyawan]);
    }

    /**
     * Display the specified resource.
     */
    public function show(Karyawan $karyawan)
    {
        if ($karyawan->foto) {
            $karyawan->foto = Storage::url($karyawan->foto); // Menambahkan URL foto
        }

        return response()->json($karyawan);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Karyawan $karyawan)
    {
        $validated = $request->validate([
            'nama' => 'nullable|string|max:255',
            'alamat' => 'nullable|string|max:255',
            'no_ktp' => 'nullable|string|max:255',
            'gaji' => 'nullable|string|max:255',
            'kontrak' => 'nullable|date',
            'foto' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        // Handle file upload and delete old file if new one is provided
        if ($request->hasFile('foto')) {
            // Delete old file if exists
            if ($karyawan->foto) {
                Storage::disk('public')->delete($karyawan->foto);
            }
            $validated['foto'] = $request->file('foto')->store('karyawan', 'public');
        }

        $karyawan->update($validated);

        // Menambahkan URL foto yang baru diupdate
        if ($karyawan->foto) {
            $karyawan->foto = Storage::url($karyawan->foto);
        }

        return response()->json(['message' => 'Karyawan updated successfully', 'data' => $karyawan]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Karyawan $karyawan)
    {
        // Delete file if exists
        if ($karyawan->foto) {
            Storage::disk('public')->delete($karyawan->foto);
        }

        $karyawan->delete();
        return response()->json(['message' => 'Karyawan deleted successfully']);
    }
}
