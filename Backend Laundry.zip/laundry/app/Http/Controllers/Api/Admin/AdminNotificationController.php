<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use Illuminate\Http\Request;

class AdminNotificationController extends Controller
{
    /**
     * Menampilkan semua notifikasi yang dikirim oleh customer.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        // Ambil semua notifikasi yang berasal dari customer
        $notifications = Notification::whereHas('user', function($query) {
            // Misalnya, customer memiliki role_id lebih rendah daripada admin
            $query->where('role_id', 1);  // Ganti dengan role_id untuk customer
        })
        ->orderBy('created_at', 'desc') // Urutkan berdasarkan yang terbaru
        ->get();

        // Jika tidak ada notifikasi
        if ($notifications->isEmpty()) {
            return response()->json([
                'success' => false,
                'message' => 'Tidak ada notifikasi yang dikirim dari customer.',
            ], 404);
        }

        // Kembalikan notifikasi dalam format JSON
        return response()->json([
            'success' => true,
            'notifications' => $notifications,
        ]);
    }

    /**
     * Menghapus notifikasi berdasarkan ID untuk admin.
     *
     * @param int $notificationId
     * @return \Illuminate\Http\JsonResponse
     */
    public function delete($notificationId)
    {
        // Ambil notifikasi berdasarkan ID
        $notification = Notification::findOrFail($notificationId);

        // Hapus notifikasi
        $notification->delete();

        // Kembalikan respons sukses
        return response()->json([
            'success' => true,
            'message' => 'Notifikasi berhasil dihapus.',
        ]);
    }
}
