<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Voucher2;  // Adjusted to Voucher2 model
use Illuminate\Http\Request;

class Voucher2Controller extends Controller
{
    /**
     * Menampilkan semua voucher.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        $vouchers = Voucher2::all();  // Mengambil semua data voucher2
        return response()->json([
            'success' => true,
            'data' => $vouchers,
        ]);
    }

    /**
     * Menyimpan voucher baru.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(Request $request)
    {
        // Validasi input
        $request->validate([
            'nama' => 'required|string|max:255',
            'harga' => 'required|string|max:255',
            'qty' => 'required|integer',
        ]);

        // Menyimpan data voucher baru
        $voucher = Voucher2::create([  // Changed to Voucher2 model
            'nama' => $request->nama,
            'harga' => $request->harga,
            'qty' => $request->qty,
        ]);

        return response()->json([
            'success' => true,
            'data' => $voucher,
        ], 201);
    }

    /**
     * Menampilkan detail voucher berdasarkan ID.
     *
     * @param  \App\Models\Voucher2 $voucher
     * @return \Illuminate\Http\JsonResponse
     */
    public function show(Voucher2 $voucher)  // Changed to Voucher2
    {
        return response()->json([
            'success' => true,
            'data' => $voucher,
        ]);
    }

    /**
     * Memperbarui data voucher.
     *
     * @param \Illuminate\Http\Request $request
     * @param \App\Models\Voucher2 $voucher
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(Request $request, Voucher2 $voucher)  // Changed to Voucher2
    {
        // Validasi input
        $request->validate([
            'nama' => 'required|string|max:255',
            'harga' => 'required|string|max:255',
            'qty' => 'required|integer',
        ]);

        // Memperbarui data voucher
        $voucher->update([
            'nama' => $request->nama,
            'harga' => $request->harga,
            'qty' => $request->qty,
        ]);

        return response()->json([
            'success' => true,
            'data' => $voucher,
        ]);
    }

    /**
     * Menghapus voucher berdasarkan ID.
     *
     * @param \App\Models\Voucher2 $voucher
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy(Voucher2 $voucher)  // Changed to Voucher2
    {
        // Menghapus voucher
        $voucher->delete();

        return response()->json([
            'success' => true,
            'message' => 'Voucher berhasil dihapus',
        ]);
    }
}
