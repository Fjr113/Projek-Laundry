<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Notification;
use Illuminate\Http\Request;

class AdminOrderController extends Controller
{
    /**
     * Update the status of an order.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $orderId
     * @return \Illuminate\Http\JsonResponse
     */
    public function updateStatus(Request $request, $orderId)
    {
        // Validate the incoming request data
        $request->validate([
            'status_id' => 'required|exists:statuses,id', // Ensure the status exists
        ]);

        // Find the order by its ID
        $order = Order::findOrFail($orderId);

        // Check if the status is being changed back to "belum bayar" (status id 1) from a non-1 status
        if ($order->status_id != 1 && $request->status_id == 1) {
            return response()->json([
                'success' => false,
                'message' => 'Cannot revert to "belum bayar" status.',
            ], 400);
        }

        // Define status messages for each status id
        $statusMessages = [
            2 => 'Diproses',
            3 => 'Dikirim',
            4 => 'Selesai',
            5 => 'Dibatalkan',
        ];

        // Check if the status has actually changed
        if ($order->status_id != $request->status_id) {
            // Update the status of the order
            $order->status_id = $request->status_id;
            $order->save();

            // If the status change is valid and requires notification (status 2 to 5), send notification
            if ($request->status_id >= 2 && $request->status_id <= 5) {
                // Create a notification for the user
                Notification::create([
                    'user_id' => $order->user_id, // User who placed the order
                    'order_id' => $order->id, // The order that was updated
                    'id_pesanan' => $order->order_code, // Order ID as id_pesanan
                    'message' => 'Pesanan Anda sedang ' . $statusMessages[$request->status_id] . '. Order ID: ' . $order->order_code,
                ]);
            }

            return response()->json([
                'success' => true,
                'message' => 'Order status updated successfully and notification sent to user.',
                'order' => $order,
            ], 200);
        }

        return response()->json([
            'success' => false,
            'message' => 'No status change detected.',
        ], 400);
    }
}
