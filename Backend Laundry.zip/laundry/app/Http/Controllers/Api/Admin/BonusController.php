<?php

namespace App\Http\Controllers\Api\Admin;

use App\Models\Bonus;
use App\Models\Karyawan;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class BonusController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // Menampilkan semua data bonus
        $bonuses = Bonus::with('karyawan')->get();
        return response()->json([
            'message' => 'Bonuses retrieved successfully',
            'data' => $bonuses
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Validasi data yang diterima
        $validated = $request->validate([
            'karyawan_id' => 'required|exists:karyawan,id',
            'keterangan' => 'required|string|max:255',
            'bonusnya' => 'required|string|max:255',
        ]);

        // Membuat bonus baru
        $bonus = Bonus::create($validated);

        return response()->json([
            'message' => 'Bonus created successfully',
            'data' => $bonus
        ]);
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        // Menampilkan detail bonus berdasarkan ID
        $bonus = Bonus::with('karyawan')->findOrFail($id);
        return response()->json([
            'message' => 'Bonus retrieved successfully',
            'data' => $bonus
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        // Validasi data yang diterima
        $validated = $request->validate([
            'karyawan_id' => 'nullable|exists:karyawan,id',
            'keterangan' => 'nullable|string|max:255',
            'bonusnya' => 'nullable|string|max:255',
        ]);

        // Cari bonus berdasarkan ID
        $bonus = Bonus::findOrFail($id);
        $bonus->update($validated);

        return response()->json([
            'message' => 'Bonus updated successfully',
            'data' => $bonus
        ]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        // Cari dan hapus bonus berdasarkan ID
        $bonus = Bonus::findOrFail($id);
        $bonus->delete();

        return response()->json([
            'message' => 'Bonus deleted successfully'
        ]);
    }
}
