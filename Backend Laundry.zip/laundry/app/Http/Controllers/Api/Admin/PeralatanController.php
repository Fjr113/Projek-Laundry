<?php

namespace App\Http\Controllers\Api\Admin;

use App\Models\Peralatan;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;

class PeralatanController extends Controller
{
    public function index()
{
    // Menampilkan semua data peralatan dengan URL foto
    $peralatan = Peralatan::all()->map(function ($item) {
        if ($item->foto) {
            $item->foto = Storage::url($item->foto);  // Mengubah foto menjadi URL publik
        }
        return $item;
    });

    return response()->json([
        'message' => 'Peralatan retrieved successfully',
        'data' => $peralatan
    ]);
}


    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Validasi data yang diterima
        $validated = $request->validate([
            'nama' => 'required|string|max:255',
            'harga' => 'required|string|max:255',
            'foto' => 'nullable|file|mimes:jpeg,png,jpg|max:2048',
        ]);

        // Upload file foto jika ada
        if ($request->hasFile('foto')) {
            $validated['foto'] = $request->file('foto')->store('peralatan', 'public');
        }

        // Membuat peralatan baru
        $peralatan = Peralatan::create($validated);

        return response()->json([
            'message' => 'Peralatan created successfully',
            'data' => $peralatan
        ]);
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        // Menampilkan detail peralatan berdasarkan ID
        $peralatan = Peralatan::findOrFail($id);
        if ($peralatan->foto) {
            $peralatan->foto = Storage::url($peralatan->foto);
        }

        return response()->json([
            'message' => 'Peralatan retrieved successfully',
            'data' => $peralatan
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        // Validasi data yang diterima
        $validated = $request->validate([
            'nama' => 'nullable|string|max:255',
            'harga' => 'nullable|string|max:255',
            'foto' => 'nullable|file|mimes:jpeg,png,jpg|max:2048',
        ]);

        // Cari peralatan berdasarkan ID
        $peralatan = Peralatan::findOrFail($id);

        // Jika ada foto baru, hapus foto lama dan upload foto baru
        if ($request->hasFile('foto')) {
            if ($peralatan->foto) {
                Storage::disk('public')->delete($peralatan->foto);
            }
            $validated['foto'] = $request->file('foto')->store('peralatan', 'public');
        }

        // Update peralatan
        $peralatan->update($validated);

        // Menambahkan URL foto jika ada
        if ($peralatan->foto) {
            $peralatan->foto = Storage::url($peralatan->foto);
        }

        return response()->json([
            'message' => 'Peralatan updated successfully',
            'data' => $peralatan
        ]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        // Cari dan hapus peralatan berdasarkan ID
        $peralatan = Peralatan::findOrFail($id);

        // Hapus foto jika ada
        if ($peralatan->foto) {
            Storage::disk('public')->delete($peralatan->foto);
        }

        // Hapus peralatan
        $peralatan->delete();

        return response()->json([
            'message' => 'Peralatan deleted successfully'
        ]);
    }
}
