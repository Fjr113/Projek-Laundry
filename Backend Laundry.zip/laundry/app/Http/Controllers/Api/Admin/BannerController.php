<?php

namespace App\Http\Controllers\Api\Admin;

use App\Models\Banner;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;

class BannerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // Mengambil semua data Banner dan menambahkan URL gambar
        $banners = Banner::all()->map(function ($banner) {
            // Menyisipkan URL gambar langsung di field 'gambar'
            $banner->gambar = Storage::url($banner->gambar);
            return $banner;
        });

        return response()->json([
            'success' => true,
            'message' => 'List Data Banner',
            'data' => $banners,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validasi input
        $validator = Validator::make($request->all(), [
            'judul'    => 'required|string',
            'deskripsi' => 'required|string',
            'gambar'   => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048', // Validasi gambar
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        // Cek jika jumlah banner yang ada lebih dari 4
        $bannerCount = Banner::count();
        if ($bannerCount >= 4) {
            return response()->json([
                'success' => false,
                'message' => 'Jumlah banner tidak boleh lebih dari 4',
            ], 400);
        }

        // Menyimpan gambar
        $imagePath = $request->file('gambar')->store('banners', 'public'); // Menyimpan gambar di folder public/banners

        // Simpan data Banner
        $banner = Banner::create([
            'judul'    => $request->judul,
            'deskripsi' => $request->deskripsi,
            'gambar'   => $imagePath,  // Simpan path gambar
        ]);

        // Menyisipkan URL gambar langsung di field 'gambar'
        $banner->gambar = Storage::url($banner->gambar);

        return response()->json([
            'success' => true,
            'message' => 'Data Banner Berhasil Disimpan!',
            'data' => $banner,
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        // Menampilkan detail data Banner berdasarkan ID
        $banner = Banner::find($id);

        if ($banner) {
            // Menyisipkan URL gambar langsung di field 'gambar'
            $banner->gambar = Storage::url($banner->gambar);

            return response()->json([
                'success' => true,
                'message' => 'Detail Data Banner',
                'data' => $banner,
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Detail Data Banner Tidak Ditemukan',
        ], 404);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Banner  $banner
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Cari banner berdasarkan ID
        $banner = Banner::find($id);

        if (!$banner) {
            return response()->json([
                'success' => false,
                'message' => 'Banner tidak ditemukan',
            ], 404);
        }

        // Hapus gambar dari storage jika ada
        if (Storage::exists('public/' . $banner->gambar)) {
            Storage::delete('public/' . $banner->gambar);
        }

        // Hapus data Banner dari database
        $banner->delete();

        return response()->json([
            'success' => true,
            'message' => 'Banner berhasil dihapus!',
        ]);
    }
}


