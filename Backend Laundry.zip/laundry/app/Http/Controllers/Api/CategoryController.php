<?php

namespace App\Http\Controllers\Api;

use App\Models\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class CategoryController extends Controller
{

    /**
     * Display a specific category by its ID.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        try {
            // Find the category by ID
            $category = Category::find($id);

            if (!$category) {
                return response()->json(['message' => 'Category not found.'], 404);
            }

            return response()->json(['category' => $category], 200);
        } catch (\Exception $exception) {
            return response()->json(['message' => 'Error fetching category data'], 500);
        }
    }
    /**
     * Display a listing of the categories.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return response()->json(Category::all());
    }

    /**
     * Update the price of a category.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function updatePrice(Request $request, Category $category)
    {
        $request->validate([
            'price' => 'required|numeric|min:0',
        ]);

        $category->price = $request->input('price');
        $category->save();

        return response()->json(['message' => 'Price updated successfully.']);
    }
}
