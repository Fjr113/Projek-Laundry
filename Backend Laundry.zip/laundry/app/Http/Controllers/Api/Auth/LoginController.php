<?php

namespace App\Http\Controllers\Api\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Tymon\JWTAuth\Facades\JWTAuth;
use App\Models\User;
use App\Models\Audit;
use App\Models\Ban;
use Carbon\Carbon;

class LoginController extends Controller
{
    public function loginLocal(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'identifier' => 'required',
            'password' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        $credentials = $request->only('identifier', 'password');

        // Cari user berdasarkan email atau username
        $user = User::where(function ($query) use ($credentials) {
            $query->where('email', $credentials['identifier'])
                  ->orWhere('username', $credentials['identifier']);
        })->first();

        if (!$user || !\Hash::check($credentials['password'], $user->password)) {
            return response()->json([
                'success' => false,
                'message' => 'Email/Username atau Password salah',
            ], 400);
        }

        // Cek apakah user diblokir
        $ban = Ban::where('user_id', $user->id)->first();
        if ($ban) {
            $banExpired = Carbon::parse($ban->expired);
            if ($banExpired->isFuture()) {
                return response()->json([
                    'success' => true,
                    'warning' => true,
                    'message' => 'Akun Anda saat ini dalam status diblokir.',
                    'ban_message' => $ban->message,
                    'banned_until' => $banExpired->format('Y-m-d H:i:s'),
                ], 200);
            }
        }

        // Jika tidak diblokir, lanjutkan login
        $token = auth()->guard('api')->login($user);

        // Tambahkan log audit
        Audit::create([
            'user_id' => $user->id,
            'action' => 'login_local',
            'description' => 'Pengguna berhasil login menggunakan kredensial lokal.',
        ]);

        return $this->respondWithToken($user, $token);
    }

    public function loginGoogle(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'google_id' => 'required',
            'email' => 'required|email',
            'username' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        // Cari user berdasarkan Google ID
        $user = User::where('google_id', $request->google_id)
                    ->where('role_id', 2)
                    ->first();

        // Cek apakah user diblokir
        if ($user) {
            $ban = Ban::where('user_id', $user->id)->first();
            if ($ban) {
                $banExpired = Carbon::parse($ban->expired);
                if ($banExpired->isFuture()) {
                    return response()->json([
                        'success' => true,
                        'warning' => true,
                        'message' => 'Akun Anda saat ini dalam status diblokir.',
                        'ban_message' => $ban->message,
                        'banned_until' => $banExpired->format('Y-m-d H:i:s'),
                    ], 200);
                }
            }
        }

        // Jika pengguna belum terdaftar, buat akun baru
        if (!$user) {
            $user = User::create([
                'username' => $request->username,
                'email' => $request->email,
                'google_id' => $request->google_id,
                'role_id' => 2, // Pastikan role_id tetap customer
                'password' => bcrypt('default_password'),
            ]);
        }

        // Buat token JWT
        $token = auth()->guard('api')->login($user);

        // Tambahkan log audit
        Audit::create([
            'user_id' => $user->id,
            'action' => 'login_google',
            'description' => 'Pengguna berhasil login menggunakan kredensial Google.',
        ]);

        return $this->respondWithToken($user, $token);
    }


public function logout()
    {
        $user = auth()->guard('api')->user();
        JWTAuth::invalidate(JWTAuth::getToken());

        if ($user) {
            Audit::create([
                'user_id' => $user->id,
                'action' => 'logout',
                'description' => 'Pengguna berhasil logout.',
            ]);
        }

        return response()->json([
            'success' => true,
            'message' => 'Berhasil logout',
        ], 200);
    }

    /**
     * Respon dengan token JWT.
     */
    private function respondWithToken($user, $token)
    {
        return response()->json([
            'success' => true,
            'user' => $user->only(['username', 'email', 'google_id']),
            'permissions' => $user->getPermissionArray(),
            'roles' => $user->getRoleNames(),
            'token' => $token,
        ], 200);
    }
    
}
