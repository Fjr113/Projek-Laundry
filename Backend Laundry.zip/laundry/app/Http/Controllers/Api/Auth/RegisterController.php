<?php

namespace App\Http\Controllers\Api\Auth;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Spatie\Permission\Models\Role;

class RegisterController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        // Validasi data
        $validator = Validator::make($request->all(), [
            'username'              => 'required|unique:users,username',
            'email'                 => 'required|email|unique:users,email',
            'password'              => 'required|min:8|confirmed', // Validasi konfirmasi password
            'password_confirmation' => 'required', // Pastikan password_confirmation diisi
        ]);

        // Jika validasi gagal
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors'  => $validator->errors(),
            ], 422);
        }

        // Ambil role 'customer'
        $role = Role::where('name', 'customer')->first();

        if (!$role) {
            return response()->json([
                'success' => false,
                'message' => 'Role customer not found. Please ensure it is seeded in the database.',
            ], 500);
        }

        // Buat user
        $user = User::create([
            'username'  => $request->username,
            'email'     => $request->email,
            'password'  => bcrypt($request->password),
            'role_id'   => $role->id,
        ]);

        // Berikan role kepada user
        $user->assignRole($role->name);

        // Berikan response berhasil
        return response()->json([
            'success' => true,
            'user'    => $user,
        ], 201);
    }
}
