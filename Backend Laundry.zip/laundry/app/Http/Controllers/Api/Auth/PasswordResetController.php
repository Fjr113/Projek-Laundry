<?php

namespace App\Http\Controllers\Api\Auth;

use App\Models\User;
use App\Models\PasswordReset;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Carbon\Carbon;
use App\Http\Controllers\Controller;

class PasswordResetController extends Controller
{
    public function sendResetLink(Request $request)
    {
        // Validasi email
        $request->validate([
            'email' => 'required|email|exists:users,email',
        ]);

        // Cari pengguna berdasarkan email
        $user = User::where('email', $request->email)->first();

        // Generate kode reset
        $code = Str::random(6);

        // Simpan kode reset ke tabel password_resets
        PasswordReset::updateOrCreate(
            ['email' => $request->email],
            [
                'code' => $code,
                'created_at' => Carbon::now(),
            ]
        );

        // Kirim email
        Mail::send('emails.password_reset', ['code' => $code], function ($message) use ($user) {
            $message->to($user->email)
                ->subject('Reset Password')
                ->from(env('MAIL_FROM_ADDRESS'), env('MAIL_FROM_NAME')); // Gunakan pengaturan dari .env
        });

        return response()->json(['message' => 'Kode reset telah dikirim ke email Anda.'], 200);
    }

    public function resetPassword(Request $request)
    {
        // Validasi input
        $request->validate([
            'email' => 'required|email|exists:users,email',
            'code' => 'required|string|size:6',
            'password' => 'required|min:8|confirmed',
        ]);

        // Cek apakah kode reset valid
        $passwordReset = PasswordReset::where('email', $request->email)
                                      ->where('code', $request->code)
                                      ->first();

        if (!$passwordReset || Carbon::parse($passwordReset->created_at)->addMinutes(30)->isPast()) {
            return response()->json(['message' => 'Kode reset tidak valid atau telah kadaluarsa.'], 400);
        }

        // Cari pengguna dan reset password
        $user = User::where('email', $request->email)->first();
        $user->password = bcrypt($request->password);
        $user->save();

        // Hapus kode reset setelah berhasil mereset password
        $passwordReset->delete();

        return response()->json(['message' => 'Password berhasil direset.'], 200);
    }
}
