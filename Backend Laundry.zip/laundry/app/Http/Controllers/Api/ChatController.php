<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Message;
use App\Models\User;
use App\Events\MessageSent;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ChatController extends Controller
{
    // Mengambil semua pesan
    public function fetchMessages(Request $request)
    {
        $user = Auth::user();

        // Jika admin, ambil semua pesan
        if ($user->role_id == 1) { // Role ID 1 untuk admin
            $messages = Message::with('sender', 'receiver')->get();
        } else {
            // Jika bukan admin, ambil pesan yang terkait dengan user
            $messages = Message::where(function ($query) use ($user) {
                $query->where('sender_id', $user->id)
                      ->orWhere('receiver_id', $user->id);
            })
            ->with('sender', 'receiver')
            ->get();
        }

        // Menambahkan nama pengirim dan penerima ke data pesan
        $messages = $messages->map(function ($message) {
            $message->sender_name = $message->sender->username;
            $message->receiver_name = $message->receiver->username;
            return $message;
        });

        return response()->json(['success' => true, 'messages' => $messages]);
    }

    // Mengirim pesan
    public function sendMessage(Request $request)
    {
        $request->validate([
            'receiver_id' => 'required|exists:users,id',
            'message' => 'required|string',
        ]);

        $sender = Auth::user();
        $receiver = User::find($request->receiver_id);

        // Validasi untuk non-admin (admin bebas mengirim ke siapa saja)
        if ($sender->role_id != 1) {
            if ($sender->role_id == 2 && $receiver->role_id != 1) {
                return response()->json(['error' => 'Customer hanya dapat mengirim pesan ke admin.'], 403);
            }
        }

        // Membuat pesan
        $message = Message::create([
            'sender_id' => $sender->id,
            'receiver_id' => $receiver->id,
            'message' => $request->message,
        ]);

        // Emit event
        event(new MessageSent($message));

        // Menambahkan nama pengirim dan penerima ke data pesan
        $message->sender_name = $message->sender->username;
        $message->receiver_name = $message->receiver->username;

        return response()->json(['success' => true, 'message' => $message]);
    }

    // Menampilkan daftar semua pengguna (khusus admin)
    public function fetchUsers()
    {
        $user = Auth::user();

        // Pastikan hanya admin yang dapat mengakses
        if ($user->role_id != 1) {
            return response()->json(['error' => 'Hanya admin yang dapat mengakses daftar pengguna.'], 403);
        }

        // Ambil semua pengguna kecuali admin
        $users = User::where('role_id', '!=', 1)->get(['id', 'username', 'role_id']);

        return response()->json(['success' => true, 'users' => $users]);
    }
}
